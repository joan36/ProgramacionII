/*
 * Programa que fa la lectura d'un enter en xifres romanes suposant que no hi ha
 * cap error en l'entrada.
 *
 * El programa llegeix una cadena de caràcters la xifrea romana crida el
 * mètode valorDe i treu l'enter resultant. El mètode valorDe suposa que al
 * final de la cadena hi ha el blanc i va llegint fins tronar-lo. El tractament
 * es fa en parelles de caràcters que es van sumant si són iguals o menors i
 * restant en cas contrari.
 *
 * El mètode valorDigit és el que tradueix els signes als seus valors. A la
 * segona versió s'aprofita el fet que per calcular el valors és igual que
 * alternativament anar multiplicant per 5 i per 2.
 */
package _xifresromanes4;

/**
 *
 * @author miquelmascaro
 */
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class XifresRomanes4 {

    public static void main(String[] args) {
        try {
            System.out.println("Programa de lectura d'un enter "
                    + "en xifres romanes");
            System.out.print("Insereix la xifra romana: ");
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            String r = in.readLine();
            r += ' '; //Afegim un blanc a la cadena
            int n = valorDe(r);
            System.out.print("El valor de la xifra romana és: " + n + "\n");
        } catch (Exception e) {
        }
    }

    private static int valorDe(String r) {
        int s = 0;
        int i = 0;
        int vi = valorDigit(r.charAt(i));
        for (i = 0; r.charAt(i) != ' '; i++) {
            int vi1 = valorDigit(r.charAt(i + 1));
            if (vi >= vi1) {
                s += vi;
            } else {
                s -= vi;
            }
            vi = vi1;
        }
        return s;
    }

    private static int valorDigit(char c) {
        final String sym = "IVXLCDMFT ";
        final int v[] = new int[]{1, 5, 10, 50, 100, 500, 1000, 5000, 10000, 0};
        int i = 0;
        while (c != sym.charAt(i)) {
            i++;
        }
        return v[i];
    }


//    private static int valorDigit(char c) {
//        final String sym = "IVXLCDMFT";
//        int v = 0;
//        if (c != ' ') {
//            int i = 0;
//            v = 1;
//            boolean Parell = true;
//            while (c != sym.charAt(i)) {
//                i++;
//                Parell = !Parell;
//                if (Parell) {
//                    v *= 2;
//                } else {
//                    v *= 5;
//                }
//            }
//        }
//        return v;
//    }
}
