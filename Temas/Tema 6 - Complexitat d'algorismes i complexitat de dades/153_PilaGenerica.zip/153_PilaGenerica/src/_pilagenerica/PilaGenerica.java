/*
 * Exemple d'us de la pila genèrica per definir una pila d'enters.
 *
 * Mitjançant un menú senzill es gestionen les opcions d'afagir i llevar
 * elements i de buidar tota la pila.
 *
 * Observi's la independència de la pila amb l'E/S
 */
package _pilagenerica;

/**
 *
 * @author miquelmascarooliver
 */
import java.io.*;

public class PilaGenerica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pila<Integer> pilaEnters = new Pila<Integer>(10);
        boolean sortir = false;
        int opcio = 0;
        while (!sortir) {
            menu();
            opcio = llegirEnter("\n\n\tInserir opció: ");
            switch (opcio) {
                case 1:
                    try {
                        int x = llegirEnter("Insereix un enter a posar: ");
                        pilaEnters.posar(x);
                    } catch (Pila.PilaPlena e) {
                        System.out.println("ERROR: La pila està plena no es"
                                + "poden  posar més elements");
                    }
                    break;
                case 2:
                    try {
                        int x = pilaEnters.treure();
                        System.out.println("L'element tret és: " + x);
                    } catch (Pila.PilaBuida e) {
                        System.out.println("ERROR: " + e.getMessage());
                    }
                    break;
                case 3:
                    int i = 1;
                    while (!pilaEnters.esBuida()) {
                        try {
                            System.out.println("Element " + i + ": "
                                    + pilaEnters.treure());
                            i++;
                        } catch (Pila.PilaBuida e) {
                            System.out.println("ERROR: " + e.getMessage());
                        }
                    }
                    System.out.println("La pila està buida");
                    break;
                case 0:
                    sortir = true;
                    break;
            }
        }
    }

    private static void menu() {
        System.out.println("\n\nPila enters");
        System.out.println("\n\t1. Posar un enter");
        System.out.println("\t2. Treure un enter");
        System.out.println("\t3. Treure tots els enters");
        System.out.println("\t0. Sortir");
    }

    private static int llegirEnter(String msg) {
        int x = 0;
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            System.out.print(msg);
            String s = in.readLine();
            x = Integer.parseInt(s);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return x;
    }
}
