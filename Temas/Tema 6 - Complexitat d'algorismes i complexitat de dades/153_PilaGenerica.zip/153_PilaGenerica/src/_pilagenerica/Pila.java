/*
 * Classe Pila. Permet definir de forma genèrica una pila d'elements qualsevols
 * i les operacions habituals sobre aquestes estructures.
 *
 * Una pila està definida pel seu tameny (dimensió de l'array), taula d'elements
 * cualsevols i un índex que indica el nombre d'elements de la pila. Per que la
 * pila sigui abstracta aquests elements es definiran com a privats. Com que és
 * genèrica, quan es defineixi la pla s'hauràn d'indicar com són els elements
 * que emmagatzema (notació entre menor i major).
 *
 * Es defineixen dos errors possibles PilaPlena i PilaBuida, observi's dos
 * exemples diferents en el tractament dels missatges d'errors.
 *
 * El constructor defineix una pila de tants d'elements com el paràmetre que
 * passa. Si el paràmetre és negatiu o zero la pila és de 10 elements. Es
 * defineix la taula d'elements segons el tipus indicat a la declaració de la
 * pila genèrica i l'index n indica que no hi ha cap element posició -1 ja que a
 * la 0 hi haurà el primer.
 *
 * El mètode posa posar l'item que es passa per paràmetre dins la pila
 * incrementant l'índex i en aquesta posició hi emmagatzema l'element, si la
 * pila està plena activa la corresponent excepció.
 *
 * El mètode treure lleva un element de la pila si no està buida.
 *
 * Els mètodes esPlena i esBuida retornaran un booleà si la pila és plena o si
 * està buida respectivament.
 */
package _pilagenerica;

/**
 *
 * @author miquelmascarooliver
 */
public class Pila<E> {

    public static class PilaPlena extends Exception {
    }

    public static class PilaBuida extends Exception {

        public PilaBuida(String e) {
            super(e);
        }
    }


    private final int tamany;
    private E[] elements;
    private int n;

    public Pila(int s) {
        tamany = s > 0 ? s : 10;
        elements = (E[]) new Object[tamany];
        n = -1; // pila buida, índex de l'element de d'alt LIFO
    }

    public void posar(E item) throws PilaPlena { //push
        if (n == tamany - 1) {
            throw new PilaPlena();
        }
        n++;
        elements[n] = item;
    }

    public E treure() throws PilaBuida { //pop
        if (n == -1) {
            throw new PilaBuida("La pila està buida no es pot treure cap"
                    + " element");
        }
        return elements[n--];
    }

    public boolean esPlena() {
        return n == tamany -1;
    }

    public boolean esBuida() {
        return n == -1;
    }
}
