package pkg148_xifresromanes2ambclasse;


/**
 *
 * @author miquelmascarooliver
 */
public class XifraRomana {

    private String x;

    /**
     * Contructor que converteix a la representació de xifra romana
     * l'enter que passa com a paràmetre. Descomposa l'enter i en fa
     * la seva representació xifra a xifra depenent del seu ordre fins
     * arribar a ordre 0
     * @param nombre 
     */
    public XifraRomana(int nombre) {
        x = "";
        try {
            if (nombre < 0 || nombre > 9999) {
                throw new nombreNoRepresentable("Nombre no representable en "
                        + "xifres romanes");
            }
            int ord = 3;
            int divi = 1000;
            int nr = nombre;
            while (ord >= 0) {
                int xifra = nr / divi;
                nr = nr % divi;
                x += repRoma(xifra, ord);
                ord--;
                divi /= 10;
//                System.out.println(" " + ord + " " + xifra + " " + divi);
            }
            System.out.print("\n");
        } catch (nombreNoRepresentable e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    private static String repRoma(int xifra, int ord) {
        String s = "";
        String tipus[] = new String[]{
            " ", "0 ", "00 ", "000 ", "01 ", "1 ", "10 ", "100 ", "1000 ",
            "02 "};
        char simbol[][] = new char[][]{
            {'I', 'X', 'C', 'M'},
            {'V', 'L', 'D', 'F'},
            {'X', 'C', 'M', 'T'}};

        int i = 0;
        while (tipus[xifra].charAt(i) != ' ') {
            int index = Character.getNumericValue(tipus[xifra].charAt(i));
            s += simbol[index][ord];
            i++;
            
            int j = 0;
        }
        return s;
    }

    @Override
    public String toString() {
        return x;
    }
    
    
}
