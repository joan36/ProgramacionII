package pkg147_xifresromanesambclasse;

/**
 *
 * @author miquelmascarooliver
 */
public class XifraRomana {

    private String x;

    /**
     * Contructor que converteix a la representació de xifra romana
     * l'enter que passa com a paràmetre. Descomposa l'enter i en fa
     * la seva representació xifra a xifra depenent del seu ordre fins
     * arribar a ordre 0
     * @param nombre 
     */
    public XifraRomana(int nombre) {
        x = "";
        try {
            if (nombre < 0 || nombre > 9999) {
                throw new nombreNoRepresentable("Nombre no representable en "
                        + "xifres romanes");
            }
            int ord = 3;
            int divi = 1000;
            int nr = nombre;
            while (ord >= 0) {
                int xifra = nr / divi;
                nr = nr % divi;
                x += repRoma(xifra, ord);
                ord--;
                divi /= 10;
//                System.out.println(" " + ord + " " + xifra + " " + divi);
            }
//            System.out.print("\n");
        } catch (nombreNoRepresentable e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    private static String repRoma(int xifra, int ord) {
        final String NRom[][] = new String[][]{
            {" ", " ", " ", " "},
            {"I ", "X ", "C ", "M "},
            {"II ", "XX ", "CC ", "MM "},
            {"III ", "XXX ", "CCC ", "MMM "},
            {"IV ", "XL ", "CD ", "MF "},
            {"V ", "L ", "D ", "F "},
            {"VI ", "LX ", "DC ", "FM "},
            {"VII ", "LXX ", "DCC ", "FMM "},
            {"VIII ", "LXXX ", "DCCC ", "FMMM "},
            {"IX ", "XC ", "CM ", "MT "}};
        String s = "";
        int i = 0;
        while (NRom[xifra][ord].charAt(i) != ' ') {
            s += NRom[xifra][ord].charAt(i);
            i++;
        }
        return s;
    }

    @Override
    public String toString() {
        return x;
    }
    
    
}
