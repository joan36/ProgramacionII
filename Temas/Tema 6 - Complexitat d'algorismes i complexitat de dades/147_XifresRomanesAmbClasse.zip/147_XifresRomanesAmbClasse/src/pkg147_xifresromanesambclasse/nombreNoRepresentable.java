package pkg147_xifresromanesambclasse;

/**
 *
 * @author miquelmascarooliver
 */

/**
 * 
 * Excepció que s'aixeca quan s'inteta representar un nombre que no es pot
 * Escriure segons les convencions de les xifres romanes
 */
public class nombreNoRepresentable extends Exception {

    public nombreNoRepresentable(String s) {
        super(s);
    }
}
