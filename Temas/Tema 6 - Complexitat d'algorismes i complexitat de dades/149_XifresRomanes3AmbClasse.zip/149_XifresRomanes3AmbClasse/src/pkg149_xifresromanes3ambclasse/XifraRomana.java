package pkg149_xifresromanes3ambclasse;


/**
 *
 * @author miquelmascarooliver
 */
public class XifraRomana {

    private String x;

    /**
     * Contructor que converteix a la representació de xifra romana
     * l'enter que passa com a paràmetre. Descomposa l'enter i en fa
     * la seva representació xifra a xifra depenent del seu ordre fins
     * arribar a ordre 0
     * @param nombre 
     */
    public XifraRomana(int nombre) {
        x = "";
        try {
            if (nombre < 0 || nombre > 9999) {
                throw new nombreNoRepresentable("Nombre no representable en "
                        + "xifres romanes");
            }
            int ord = 3;
            int divi = 1000;
            int nr = nombre;
            while (ord >= 0) {
                int xifra = nr / divi;
                nr = nr % divi;
                x += repRoma(xifra, ord);
                ord--;
                divi /= 10;
//                System.out.println(" " + ord + " " + xifra + " " + divi);
            }
        } catch (nombreNoRepresentable e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    private static String repRoma(int xifra, int ord) {
        String s = "";
        String tipus[] = new String[]{
            " ", "0 ", "00 ", "000 ", "01 ", "1 ", "10 ", "100 ", "1000 ",
            "02 "};
        char simbol[] = new char[]{'I', 'V', 'X', 'L', 'C', 'D', 'M', 'F', 'T'};
        int posord, i = 0;
        posord = ord * 2;
        while (tipus[xifra].charAt(i) != ' ') {
            if (tipus[xifra].charAt(i) == '0') {
                s += (simbol[posord]);
            } else if (tipus[xifra].charAt(i) == '1') {
                s += (simbol[posord + 1]);
            } else {
                s += (simbol[posord + 2]);
            }
 //           s += (simbol[posord + Character.getNumericValue(tipus[xifra].charAt(i))]);
            i++;
        }
        return s;
    }

    @Override
    public String toString() {
        return x;
    }
    
    
}
