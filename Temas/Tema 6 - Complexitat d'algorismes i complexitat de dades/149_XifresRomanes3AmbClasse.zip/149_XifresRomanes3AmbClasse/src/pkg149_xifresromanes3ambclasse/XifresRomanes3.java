/*
 * Representació d'un nombre en xifres romanes
 *
 * Programa que representa els nombre romans entre 0 i 9999. És una
 * simplificació que no considera les desenes de milers. La solució es basa en
 * la descomposició de la xifra a representar en els dígits que la formen. Per
 * això comença amb l'ordre de milers i divideix per mil, va baixant d'ordre
 * fins a arribar a les unitats decrementant l'ordre i dividint per 10 el
 * divisor, aconsegueix el dígit dividint el nombre pel divisor i actualitza el
 * nombre fent el mòdul.
 *
 * En aquesta solució per fer la representació del dígit s'usa el mètode repRoma
 * que fedineix una taula bidimensional de cadenes de caràcters on es relacionen
 * les xifres romanes amb el seu corresponent ordre, la representació consisteix
 * en anar escrivint caràcter a caràcter les lletres de la cadena fins arribar
 * al blanc que delimita el final.
 */
package pkg149_xifresromanes3ambclasse;

/**
 *
 * @author miquelmascarooliver
 */
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class XifresRomanes3 {

    public static void main(String[] args) {
            System.out.println("Programa d'escriptura d'un enter en xifres romanes");
            int nombre = llegirEnter("Insereix el nombre (9999 max): ");
            XifraRomana xifra = new XifraRomana(nombre);
            System.out.println("Amb xifres romanes: " + xifra);
    }

    private static int llegirEnter(String msg) {
        int x = 0;
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            System.out.print(msg);
            String s = in.readLine();
            x = Integer.parseInt(s);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return x;
    }

}
