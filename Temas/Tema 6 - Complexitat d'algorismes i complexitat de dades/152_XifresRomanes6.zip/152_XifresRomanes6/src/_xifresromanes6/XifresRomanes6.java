/*
 * Programa que usa la classe XifraRomana
 *
 * Gestiona un menú senzill per anar d'un enter a xifra romana i al revés.
 *
 * Observi's la idependència de la classe XifraRomana de l'E/S
 */
package _xifresromanes6;

/**
 *
 * @author miquelmascarooliver
 */
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class XifresRomanes6 {

    public static void main(String[] args) {
        try {
            boolean sortir = false;
            int opcio;
            while (!sortir) {
                menu();
                opcio = llegirEnter("\n\n\tInserir opció: ");
                switch (opcio) {
                    case 1:
                        int x = llegirEnter("\n\t\t\tInserir enter: ");
                        XifraRomana xr1 = new XifraRomana(x);
                        System.out.println("La xifra romana és: " + xr1);
                        System.out.println("i el seu valor: " + xr1.valorDe());
                        break;
                    case 2:
                        BufferedReader in = new BufferedReader
                                (new InputStreamReader(System.in));
                        System.out.print("\n\t\t\tInserir xifra: ");
                        String r = in.readLine();
                        XifraRomana xr2 = new XifraRomana(r);
                        System.out.println("La xifra romana és: " + xr2);
                        System.out.println("i el seu valor: " + xr2.valorDe());
                        break;
                    case 0:
                        sortir = true;
                        break;
                }
            }
        } catch (XifraRomana.nombreNoRepresentable e1) {
            System.out.println("\nERROR: No es pot representar aquest nombre"
                    + " amb xifres romanes");
        } catch (XifraRomana.xifraRomanaIncorrecta e2) {
            System.out.println("\nERROR: La seqüència de caràcters no és una"
                    + " xifra romana");
        } catch (Exception e3) {
            System.out.println("\nERROR: " + e3.getMessage());
        }
    }

    private static void menu() {
        System.out.println("\n\nXIFRES ROMANES");
        System.out.println("\n\t1. Enter a romà");
        System.out.println("\t2. Romà a enter");
        System.out.println("\t0. Sortir");
    }

    private static int llegirEnter(String msg) {
        int x = 0;
        try {
            BufferedReader in = new BufferedReader
                    (new InputStreamReader(System.in));
            System.out.print(msg);
            String s = in.readLine();
            x = Integer.parseInt(s);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return x;
    }
}
