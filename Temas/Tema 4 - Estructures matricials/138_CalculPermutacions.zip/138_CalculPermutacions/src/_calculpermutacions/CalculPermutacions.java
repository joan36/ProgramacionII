/*
 * Càlcul de les permutacions: exemple d'algorisme combinatori
 */

package _calculpermutacions;

/**
 *
 * @author miquelmascarooliver
 */
public class CalculPermutacions {

    public static void main(String[] args) {
        Permutacio p = new Permutacio(4);
        p.primeraPermutacio();
        while (!p.darreraPermutacio()) {
            System.out.println(p);
            p.seguentPermutacio();
        }
        System.out.println(p);
    }

}
