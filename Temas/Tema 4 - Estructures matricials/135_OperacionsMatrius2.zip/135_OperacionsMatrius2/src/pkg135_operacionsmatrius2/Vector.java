package pkg135_operacionsmatrius2;

import java.util.Random;

/**
 * Classe vector
 *
 * @author miquelmascarooliver
 */
public class Vector {

    /**
     * Un vector és una col·lecció de doubles
     *
     * @param dimensio del vector
     */
    private double x[];

    /**
     * Excepció que s'aixeca quan no es pot fer una operació entre dos vectors
     */
    public static class rangsinconsistents extends Exception {

        public rangsinconsistents(String s) {
            super(s);
        }
    }

    /**
     * El vector es construeix buit indicant la dimensió
     *
     * @param dimensio
     */
    public Vector(int dimensio) {
        this.x = new double[dimensio];
    }

    /**
     * Retorna la llargaria del vector
     *
     * @return
     */
    public int getDimensio() {
        return x.length;
    }

    @Override
    public String toString() {
        String s = "(";
        for (int i = 0; i < x.length; i++) {
            s += x[i] + " ";
        }
        return s + ")";
    }

    /**
     * Retorna el mòdul o norma del vector
     *
     * @return
     */
    public double modul() {
        double s = 0;
        for (int i = 0; i < x.length; i++) {
            s += x[i] * x[i];
        }
        return Math.sqrt(s);
    }

    /**
     * Assigna a la posició i el valor x
     *
     * @param i
     * @param x
     */
    public void setValor(int i, double x) {
        this.x[i] = x;
    }

    /**
     * Emplena el vector amb valors aleatòris enters entre 0 i vsup
     *
     * @param vsup
     */
    public void ompleAleatori(int vsup) {
        Random rnd = new Random();
        for (int i = 0; i < this.x.length; i++) {
            this.x[i] = rnd.nextInt(vsup);
        }
    }

    /**
     * Producte escalar de dos vectors
     * @param v
     * @return
     * @throws pkg135_operacionsmatrius.Vector.rangsinconsistents 
     */
    public double prodEscalar(Vector v) throws rangsinconsistents {
        if (this.x.length != v.x.length) {
            throw new rangsinconsistents("Rangs inconsistents");
        }
        double s = 0;
        for (int i = 0; i < this.x.length; i++) {
            s += this.x[i] * v.x[i];
        }
        return s;
    }

}
