/*
 * Operacions amb vectors: lectura, escritura i càlcul del producte escalar
 */
package pkg135_operacionsmatrius2;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author miquelmascarooliver
 */
public class OperacionsMatrius2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Vector v1 = new Vector(3);
        Vector v2 = new Vector(5);
        v1.ompleAleatori(100);
        System.out.println("Vector v1: " + v1);
        v2.ompleAleatori(100);
        System.out.println("Vector v2: " + v2);
        System.out.print("Producte escalar v1 * v2: ");
        try {
            double m1 = v1.prodEscalar(v2);
            String s = String.format("%.2f", m1);
            System.out.println(s);
        } catch (Vector.rangsinconsistents ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
        Vector v3 = new Vector(3);
        v3.ompleAleatori(100);
        System.out.println("Vector v3: " + v3);
        System.out.print("Producte escalar v1 * v3: ");
        try {
            double m2 = v1.prodEscalar(v3);
            String s = String.format("%.2f", m2);
            System.out.println(s);
        } catch (Vector.rangsinconsistents ex) {
            Logger.getLogger(OperacionsMatrius2.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("ERROR: " + ex.getMessage());
        }
    }
}