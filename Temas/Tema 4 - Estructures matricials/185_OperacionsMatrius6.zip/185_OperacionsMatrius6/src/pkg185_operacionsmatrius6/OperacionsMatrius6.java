/*
 * Programa demana una matriu per teclat, calcula la transposta i comprova si
 * és cuadrada, simètrica, diagonal, triangular inferior i triangular superior
 */
package pkg185_operacionsmatrius6;

/**
 *
 * @author miquelmascarooliver
 */
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class OperacionsMatrius6 {


    public static void main(String[] args) {
        int files = llegirEnter("Nombre de files de la matriu: ");
        int columnes = llegirEnter("Nombre de columnes de la matriu: ");
        Matriu m = new Matriu(files, columnes);
        m.llegirmatriu();
        System.out.println("La matriu que has inserit és: ");
        m.escriureMatriu();
        Matriu t = m.transposta();
        System.out.println("La matriu trasposta és: ");
        t.escriureMatriu();
        if (m.cuadrada()) {
            System.out.println("La matriu inserida és cuadrada");
        }
        if (m.simetrica()) {
            System.out.println("La matriu inserida és simètrica");
        } else {
            System.out.println("La matriu inserida no és simètrica");
        }
        if (m.diagonal()) {
            System.out.println("La matriu inserida és diagonal");
        } else {
            System.out.println("La matriu inserida no és diagonal");
        }
        if (m.triangularInf()) {
            System.out.println("La matriu inserida és triangular inferior");
        } else {
            System.out.println("La matriu inserida no és triangular inferior");
        }
        if (m.triangularSup()) {
            System.out.println("La matriu inserida és triangular superior");
        } else {
            System.out.println("La matriu inserida no és triangular superior");
        }
    }

    private static int llegirEnter(String msg) {
        int x = 0;
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            System.out.print(msg);
            String s = in.readLine();
            x = Integer.parseInt(s);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return x;
    }
}
