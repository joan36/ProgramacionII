/*
 * Classe Vector
 *
 * El constructor defineix el vector de la dimensió que passa per paràmetre
 *
 * El mètode mòdul fa un recorregut del vector multiplicant les seves
 * components i al final en calcula l'arrel cuadrada
 *
 * Els mètodes llegirVector i escriuVector són dos recorreguts del vector
 *
 * El mètode prodEscalar fa el producte escalar de dos vectors, en cas de que
 * no tinguin lamateixa longitud es genera una excepció de rangs inconsistens
 * si tot va bé es fa un recorregut dels vectors
 *
 * El mètode assigna dona valor als elements del vector segons els elements
 * emmagatzemats en la taula que passa per paràmetre. En aquest mètode es
 * controla que les longituds siguin iguals. Observi's que a l'exemple de
 * normalitzar les matrius l'error no es donarà mai i això podria pensar-se
 * que es redundant, per un us general és del tot necessari.
 *
 * El mètode normalitza clacula la mitjana aritmética del vector.
 * 
 */
package pkg185_operacionsmatrius6;

/**
 *
 * @author miquelmascarooliver
 */
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Vector {

    /**
     *
     * @param dimensio del vector
     */
    private double x[];

    public static class rangsinconsistents extends Exception {
    }

    public Vector(int dimensio) {
        this.x = new double[dimensio];
    }

    public double modul() {
        double s = 0;
        for (int i = 0; i < x.length; i++) {
            s += x[i] * x[i];
        }
        return Math.sqrt(s);
    }

    public void llegirVector() {
        try {
            String entrada;
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(System.in));
            for (int i = 0; i < x.length; i++) {
                System.out.print("Valor " + i + ": ");
                entrada = in.readLine();
                x[i] = Double.parseDouble(entrada);
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void escriureVector() {
        System.out.print("(");
        for (int i = 0; i < x.length; i++) {
            System.out.print(x[i] + " ");
        }
        System.out.println(")");
    }

    public double prodEscalar(Vector v) {
        try {
            if (this.x.length != v.x.length) {
                throw new rangsinconsistents();
            }
        } catch (rangsinconsistents e) {
            System.out.println("Error: Rangs inconsistents");
        }
        double s = 0;
        for (int i = 0; i < this.x.length; i++) {
            s += this.x[i] * v.x[i];
        }
        return s;
    }

    void assigna(double[] v) {
        try {
            if (this.x.length != v.length) {
                throw new rangsinconsistents();
            }
            System.arraycopy(v, 0, this.x, 0, v.length);
        } catch (rangsinconsistents e) {
            System.out.println("Error: Rangs inconsistents");
        }
    }

    double normalitza() {
        double r = 0;
        for (int i = 0; i < x.length; i++) {
            r += x[i];
        }
        r = r / x.length;
        return r;
    }
}
