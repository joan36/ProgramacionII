/*
 * Classe Matriu per definir matrius de qualsevol dimensió i operacions entre
 * elles
 *
 * Es defineixen els següents atributs: m és la matriu pròpiament dita, on
 * s'emmagatzemen els valors (double en aquest cas); dos enters files i columnes
 * que permetran tractar aquests valors de la matriu.
 *
 * Es defineix l'excepció de rangsinconsistents per controlar les operacions
 * que no es poden dur a terme.
 *
 * El constructor també controla que els rangs siguin positius, això és
 * redundant ja que automàticament botaria una excepció predefinida.
 * El constructor de fineix la taula bidimensional i els enters de files i
 * columnes.
 *
 * El mètode llegirMatriu fa un recorregut per files i dins ell un per columnes
 * llegint nombres i assignant-los a les components de la matriu. Si el que es
 * llegeix no és un nombre es genera la corresponent excepció.
 *
 * El mètode escriureMatriu és un recorregut de les files i dins aquest un
 * recorregut de les columnes treient la informació de la matriu per pantalla.
 * Observi's com es pot fer referèncie amb el mètode length a files i amb
 * [0].lenght a columnes (columnes de la fila 0).
 *
 * El mètode assigna escriu els valors d'un objecte matriu dins un altre igual
 * en files i columnes, en cas contrari genera la corresponent excepció. Si
 * s'usa l'operador = si no hi ha coincidència de files i columnes no es
 * produeix cap error i la darrera matriu pren les dimensions de la matriu
 * assignada. La còpia d'una matriu a una altra es pot fer de forma manual com
 * a l'exemple o emprant System.arraycopy(orig.m[i], 0, this.m[i], 0, columnes);
 * com és suggereix al warning.
 *
 * El mètode sumar fa la suma de dues matrius aquí es presenten la versió
 * estàtica i la dinàmica. Ambdues controlen la coherència de files i columnes i
 * fan un recorregut sumant component a component.
 *
 * El mètode producte fa la multiplicació de dues matrius aquí es presenten la
 * versió estàtica i la dinàmica. Ambdues controlen la coherència de files i
 * columnes i fan un recorregut de files i dins aquest un de columnes de la
 * matriu resultant o el que és el mateix: si es multiplica A * B les files de
 * A per les columnes de B. Dins aquest recorregut s'ha  de fer la suma de
 * productes per això es fa un recorregut intern per les columnes de A (que és
 * el mateix que les files de B).
 * 
 * El mètode mitjaAritmeticaColumnes realitza la mitja aritmètica de les
 * columnes i treu el resultat en un vector. S'ha de tenir en compta que
 * l'objecte vector està definit com una tipus abstracte de manera que no
 * podem referenciar directament els seus elements, per això és defineix una
 * variable local, es calcula la mitja en aquesta variable i despréss
 * s'assigna al vector emrant un mètode de la classe. L'algorisme és un
 * recorregut de tots els elements de la matriu.
 *
 * El mètode normalitza realitza la normalització per columnes de forma
 * independent a la classe vector. Defineix una variable local que és una
 * taula de dimensió igual al nombre de columnes de la matriu, primer en
 * calcula la mitja per columnes fent un recorregut de tots els elements de la
 * matriu, després calcula la mitja dels valors emmagatzemats en aquesta
 * variable local fent un recorregut dins ella.
 * 
 * El mètode transposta retorna la matriu transposta de l'objecte al que se li
 * aplica. Això la matriu resultant de substituir les files per columnes. És un
 * recorregut de la matriu.
 * 
 * El mètode cuadrada restorna vertader si les files són igual a les columnes
 * 
 * El mètode simetrica retorna vertader si la matriu és simètrica. Per això fa
 * la cerca d'un element de la matriu que sigui diferent al corresponent de la
 * matriu transposta. Inicialment comprova que la matriu sigui cuadrada.
 * 
 * El mètode diagonal comprova que la matriu sigui triangula superior i inferior
 * i retorna vertader en cas afirmatiu. Això és el mateix que cercar un element
 * que no sigui de la diagonal i sigui diferent de zero.
 * 
 * El mètode triangularInf retorna vertader si la matriu és triangular inferior,
 * per aixó cerca un element del triangle superior de la matriu diferent de zero
 * 
 * El mètode triangularSup retorna vertader si la matriu és triangular superior,
 * per això cerca un element del triangle inferior de la matriu diferent de zero
 *
 */
package pkg185_operacionsmatrius6;

/**
 *
 * @author miquelmascarooliver
 */
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Matriu {

    /**
     *
     * @param dimensio del vector
     */
    private double m[][];
    private int files, columnes;

    public static class rangsinconsistents extends Exception {
    }

    public Matriu(int dim1, int dim2) {
        try {
            if (dim1 <= 0 || dim2 <= 0) {
                throw new rangsinconsistents();
            }
            this.m = new double[dim1][dim2];
            this.files = dim1;
            this.columnes = dim2;
        } catch (rangsinconsistents e) {
            System.out.println("Error: Rangs inconsistents");
        }
    }

    public void llegirmatriu() {
        try {
            String entrada;
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(System.in));
            for (int i = 0; i < files; i++) {
                for (int j = 0; j < columnes; j++) {
                    System.out.print("Valor (" + i + ", " + j + "): ");
                    entrada = in.readLine();
                    m[i][j] = Double.parseDouble(entrada);
                }
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void escriureMatriu() {
        System.out.print(" ");
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                System.out.print(m[i][j] + " ");
            }
            System.out.print("\n ");
        }
    }

    public void assigna(Matriu orig) {
        try {
            if (this.files != orig.files || this.columnes != orig.columnes) {
                throw new rangsinconsistents();
            }
            for (int i = 0; i < files; i++) {
                System.arraycopy(orig.m[i], 0, this.m[i], 0, columnes);
            }
        } catch (rangsinconsistents e) {
            System.out.println("Error: Rangs inconsistents");
        }
    }

    public static Matriu sumar(Matriu a, Matriu b) throws rangsinconsistents {
        if ((a.files != b.files) || (a.columnes != b.columnes)) {
            throw new rangsinconsistents();
        }
        Matriu desti = new Matriu(a.files, b.files);
        for (int i = 0; i < desti.files; i++) {
            for (int j = 0; j < desti.columnes; j++) {
                desti.m[i][j] = a.m[i][j] + b.m[i][j];
            }
        }
        return desti;
    }

    public Matriu sumar(Matriu a) throws rangsinconsistents {
        if ((this.files != a.files) || (this.columnes != a.columnes)) {
            throw new rangsinconsistents();
        }
        Matriu resultat = new Matriu(this.files, this.columnes);
        for (int i = 0; i < this.files; i++) {
            for (int j = 0; j < this.columnes; j++) {
                resultat.m[i][j] = this.m[i][j] + a.m[i][j];
            }
        }
        return resultat;
    }

    public static Matriu producte(Matriu a, Matriu b)
            throws rangsinconsistents {
        if (a.columnes != b.files) {
            throw new rangsinconsistents();
        }
        Matriu resultat = new Matriu(a.files, b.columnes);
        for (int i = 0; i < a.files; i++) {
            for (int j = 0; j < b.columnes; j++) {
                resultat.m[i][j] = 0;
                for (int k = 0; k < a.columnes; k++) {
                    resultat.m[i][j] += a.m[i][k] * b.m[k][j];
                }
            }
        }
        return resultat;
    }

    public Matriu producte(Matriu a) throws rangsinconsistents {
        if (this.columnes != a.files) {
            throw new rangsinconsistents();
        }
        Matriu resultat = new Matriu(this.files, a.columnes);
        for (int i = 0; i < this.files; i++) {
            for (int j = 0; j < a.columnes; j++) {
                resultat.m[i][j] = 0;
                for (int k = 0; k < this.columnes; k++) {
                    resultat.m[i][j] += this.m[i][k] * a.m[k][j];
                }
            }
        }
        return resultat;
    }

    public Vector mitjaAritmeticaColumnes() {
        Vector resultat = new Vector(this.columnes);
        double v[] = new double[this.columnes];
        for (int j = 0; j < this.columnes; j++) {
            v[j] = 0;
            for (int i = 0; i < this.files; i++) {
                v[j] += m[i][j];
            }
            v[j] = v[j] / this.files;
        }
        resultat.assigna(v);
        return resultat;
    }

    public double normalitza() {
        double r;
        double v[] = new double[this.columnes];
        for (int j = 0; j < this.columnes; j++) {
            v[j] = 0;
            for (int i = 0; i < this.files; i++) {
                v[j] += m[i][j];
            }
            v[j] = v[j] / this.files;
        }
        r = 0;
        for (int i = 0; i < this.columnes; i++) {
            r += v[i];
        }
        r = r / this.columnes;
        return r;
    }

    public Matriu transposta() {
        Matriu resultat = new Matriu(this.columnes, this.files);
        for (int i = 0; i < resultat.files; i++) {
            for (int j = 0; j < resultat.columnes; j++) {
                resultat.m[i][j] = this.m[j][i];
            }
        }
        return resultat;
    }

    public Boolean cuadrada() {
        return this.files == this.columnes;
    }

    public Boolean simetrica() {
        Matriu t = this.transposta();
        boolean ok = this.cuadrada();
        int i = 0;
        while (i < this.files && ok) {
            int j = 0;
            while (j < this.columnes && ok) {
                ok = this.m[i][j] == t.m[i][j];
                j++;
            }
            i++;
        }
        return ok;
    }

    public Boolean diagonal() {
//        Boolean ok = this.cuadrada();
//        int i = 0;
//        while (i < this.files && ok) {
//            int j = 0;
//            while (j < this.columnes && ok) {
//                if (i != j) {
//                    ok = this.m[i][j] == 0;
//                }
//                j++;
//            }
//            i++;
//        }
//        return ok;
        return this.triangularInf() && this.triangularSup();
    }

    public Boolean triangularInf() {
        Boolean ok = this.cuadrada();
        int i = 0;
        while (i < this.files && ok) {
            int j = i + 1;
            while (j < this.columnes && ok) {
                ok = this.m[i][j] == 0;
                j++;
            }
            i++;
        }
        return ok;
    }

    public Boolean triangularSup() {
        Boolean ok = this.cuadrada();
        int i = 0;
        while (i < this.files && ok) {
            int j = 0;
            while (j < i && ok) {
                ok = this.m[i][j] == 0;
                j++;
            }
            i++;
        }
        return ok;
    }
}
