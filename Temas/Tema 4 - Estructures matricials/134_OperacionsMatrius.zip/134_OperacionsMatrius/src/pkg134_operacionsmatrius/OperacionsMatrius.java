/*
 * Operacions amb vectors: lectura, escritura i càlcul del mòdul
 */
package pkg134_operacionsmatrius;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author miquelmascarooliver
 */
public class OperacionsMatrius {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Vector v1 = new Vector(3);
        Vector v2 = new Vector(5);
        v1 = llegirVector("Insereix els " + v1.getDimensio() + " valors del vector: ", v1.getDimensio());
        System.out.println("Vector v1: " + v1);
        v2.ompleAleatori(100); //Posarà dins el vector valors entre 0 i 100
        System.out.println("Vector v2: " + v2);
        double m1 = v1.modul();
        String s = String.format("%.2f", m1);
        System.out.println("El mòdul de v1: " + s);
        double m2 = v2.modul();
        s = String.format("%.2f", m2);
        System.out.println("El mòdul de v2: " + s);
    }

    /**
     * Entrada de dades del vector des de la finestra de text, és necessari saber
     * la dimensió del vector
     * @param msg
     * @param dim
     * @return 
     */
    private static Vector llegirVector(String msg, int dim) {
        Vector v = new Vector(dim);
        double x;
        try {
            String s;
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(System.in));
            System.out.println(msg);
            for (int i = 0; i < dim; i++) {
                System.out.print("Valor " + i + ": ");
                s = in.readLine();
                x = Double.parseDouble(s);
                v.setValor(i, x);
            }
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return v;
    }

}
