package pkg136_operacionsmatrius3;

/**
 *
 * @author miquelmascarooliver
 */

/**
 * Operacions amb matrius
 */
public class OperacionsMatrius3 {

    /**
     * @param dimensions de la matriu
     */
    public static void main(String[] args) {
        Matriu a = new Matriu(3, 2);
        Matriu b = new Matriu(2, 2);
        Matriu c = new Matriu(2, 2);
        Matriu d = new Matriu(2, 2);
        Matriu e = new Matriu(2, 2);
        a.ompleAleatori(100);
        System.out.println("Les dades de la matriu a són: \n" + a);
        b.ompleAleatori(100);
        System.out.println("Les dades de la matriu b són: \n" + b);
        try {
            c.assigna(b);
            System.out.println("S'assigna la matriu b a la c: \n" + c);
        } catch (Matriu.RangsInconsistents ex) {
            System.out.println("Error: " + ex.getMessage());           
        }
        try {
            d = Matriu.sumar(b, c);
            System.out.println("Suma de matrius b i c: \n" + d);
        } catch (Matriu.RangsInconsistents exc) {
            System.out.println("Error: " + exc.getMessage());
        }
        try {
            e = b.sumar(a);
            System.out.println("Suma de matrius b i a: \n" + e);
        } catch (Matriu.RangsInconsistents exc) {
            System.out.println("Error: " + exc.getMessage());
        }
    }
}
