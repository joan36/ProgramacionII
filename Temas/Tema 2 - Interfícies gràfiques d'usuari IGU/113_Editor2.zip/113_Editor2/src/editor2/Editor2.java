/*
 * Programa que simula el comportament d'un editor text senzill per exemplificar
 * els menús i les barres d'eines de swing
 */
package editor2;

/**
 *
 * @author miquelmascarooliver
 */
import java.awt.datatransfer.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;

public class Editor2 extends JFrame implements ClipboardOwner {

    private JMenuBar jmbarEditor;
    private JMenu jmnuFitxer;
    private JMenu jmnuEdicio;
    private JMenuItem jmItemSortir;
    private JMenuItem jmItemAferrar;
    private JMenuItem jmItemCopiar;
    private JToolBar jtbarEditor;
    private JScrollPane jscrpaneEditor;
    private JTextArea jtxtaEditor;
    private Clipboard portapapers;

    public Editor2() {
        setSize(500, 300);
        setTitle("Editor");
        setDefaultCloseOperation(Editor2.EXIT_ON_CLOSE);
        initComponents();
        portapapers = getToolkit().getSystemClipboard();
    }

    private void initComponents() {
        jmbarEditor = new JMenuBar();
        jmnuFitxer = new JMenu();
        jmnuEdicio = new JMenu();
        jmItemSortir = new JMenuItem();
        jmItemAferrar = new JMenuItem();
        jmItemCopiar = new JMenuItem();
        jtbarEditor = new JToolBar();
        jscrpaneEditor = new JScrollPane();
        jtxtaEditor = new JTextArea();

        getContentPane().setLayout(null);
        getContentPane().add(jtbarEditor);
        getContentPane().add(jmbarEditor);

        jmItemSortir.setText("Sortir");
        jmItemSortir.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evt) {
                jmItemSortirActionPerformed(evt);
            }
        });
        jmItemAferrar.setText("Aferrar");
        jmItemAferrar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evt) {
                jmItemAferrarActionPerformed(evt);
            }
        });
        jmItemCopiar.setText("Copiar");
        jmItemCopiar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evt) {
                jmItemCopiarActionPerformed(evt);
            }
        });

        jmnuFitxer.setText("Fitxer");
        jmnuFitxer.add(jmItemSortir);
        jmnuEdicio.setText("Edició");
        jmnuEdicio.add(jmItemAferrar);
        jmnuEdicio.add(jmItemCopiar);

        jmbarEditor.add(jmnuFitxer);
        jmbarEditor.add(jmnuEdicio);

        setJMenuBar(jmbarEditor);
        jtbarEditor.setBounds(0, 0, 492, 36);

        jscrpaneEditor.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);//Sempre sortirà
        jtxtaEditor.setLineWrap(true);//activació rotura de línies
        jtxtaEditor.setWrapStyleWord(true);//rotura entre paraules
        jscrpaneEditor.setViewportView(jtxtaEditor);//Assign barres a textarea
        getContentPane().add(jscrpaneEditor);
        jscrpaneEditor.setBounds(0, 36, 492, 200);
        addWindowListener(new WindowAdapter() {

            @Override
            public void windowOpened(WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
    }

    private void formWindowOpened(WindowEvent evt) {
        jtxtaEditor.requestFocus();
    }

    private void jmItemSortirActionPerformed(ActionEvent evt) {
        System.exit(0);
    }

    private void jmItemAferrarActionPerformed(ActionEvent evt) {
//        jtxtaEditor.paste();
        aferrar(evt);
    }

    private void jmItemCopiarActionPerformed(ActionEvent evt) {
//        jtxtaEditor.copy();
        copiar(evt);
    }

    //Obté l'objecte transferible que hi ha al portapapers i el col·loca a la
    //selecció o al punt d'inserció
    private void aferrar(ActionEvent evt) {
        Transferable objTrans = portapapers.getContents(this);
        if (objTrans != null) {
            try {
                String txtAferrar = (String) objTrans.getTransferData(DataFlavor.stringFlavor);
                jtxtaEditor.replaceSelection(txtAferrar);
            } catch (Exception e) {
            }
        }
    }

    //Agafa el text del que hi ha seleccionat i crea un objecte transferible
    private void copiar(ActionEvent evt) {
        String txtSel = jtxtaEditor.getSelectedText();
        Transferable objTrans = new StringSelection(txtSel);
        portapapers.setContents(objTrans, this);
    }

    public static void main(String[] args) {
        new Editor2().setVisible(true);
    }

    public void lostOwnership(Clipboard clipboard, Transferable contents) {
    }

}
