/*
 * Exemple de creació d'una finestra amb Swing
 *
 * Descriu un objecte derivat de la classe JFrame, aquest codi és una estructura
 * vàlida per cualsevol programa que mostri les seves dades en una finestra
 * principal
 *
 * La classe Finestra hereta de JFrame tots els seus mètodes a més de
 * initComponents i de exitForm
 *
 * initComponents: invoca al WindowListener per poder respondre als
 * esdeveniments de finestre com per exemple tancar-la
 *
 * exitForm: quan es tanca la finestra s'invoca aquest mètode i s'acaba
 * l'aplicació
 *
 * Cream una etiqueta i un botó: És crea l'objecte i s'afegeix al panell arrel
 */
package pkg100_finestra2;

/**
 *
 * @author miquelmascarooliver
 */
public class Finestra2 extends javax.swing.JFrame {

    private javax.swing.JLabel jEtSaludo;
    private javax.swing.JButton jBtSaludo;

    public Finestra2() {
        this.setSize(300, 200);
        this.setTitle("Finestra");
        initComponents();
    }

    private void initComponents() {
        this.jEtSaludo = new javax.swing.JLabel(); // Es crea l'objecte
        this.jBtSaludo = new javax.swing.JButton(); // Es crea l'objecte
        this.getContentPane().setLayout(null);
        this.addWindowListener(new java.awt.event.WindowAdapter() {

            @Override
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });
        this.jEtSaludo.setText("Hola món");
        this.jEtSaludo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        this.jEtSaludo.setFont(new java.awt.Font("Courier", 1, 30));
        this.getContentPane().add(jEtSaludo); // s'afegeix l'etiqueta al panell arrel
        this.jEtSaludo.setBounds(42, 36, 204, 30);
        this.jBtSaludo.setToolTipText("Pitja el botó");
        this.jBtSaludo.setMnemonic('C');// alt + c per activar el botó
        this.jBtSaludo.setText("Fes click aquí");
        this.getContentPane().add(jBtSaludo); // s'afegeix el botó al panell arrel
        this.jBtSaludo.setBounds(42, 90, 204, 30);
    }

    private void exitForm(java.awt.event.WindowEvent evt) {
        System.exit(0);
    }

    public static void main(String[] args) {
        Finestra2 f = new Finestra2();
        f.setVisible(true);
    }
}
