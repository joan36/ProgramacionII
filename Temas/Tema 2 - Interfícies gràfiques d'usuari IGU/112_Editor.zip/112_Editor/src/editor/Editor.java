/*
 * Programa que simula el comportament d'un editor text senzill per exemplificar
 * els menús i les barres d'eines de swing
 */
package editor;

/**
 *
 * @author miquelmascarooliver
 */

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JToolBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.event.*;

public class Editor extends JFrame {

    private JMenuBar jmbarEditor;
    private JToolBar jtbarEditor;
    private JScrollPane jscrpaneEditor;
    private JTextArea jtxtaEditor;

    public Editor() {
        setSize(500, 300);
        setTitle("Editor");
        setDefaultCloseOperation(Editor.EXIT_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        jmbarEditor = new JMenuBar();
        jtbarEditor = new JToolBar();
        jscrpaneEditor = new JScrollPane();
        jtxtaEditor = new JTextArea();

        getContentPane().setLayout(null);

        getContentPane().add(jtbarEditor);
        setJMenuBar(jmbarEditor);
        jtbarEditor.setBounds(0, 0, 492, 36);

        jscrpaneEditor.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);//Sempre sortirà
        jscrpaneEditor.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        jtxtaEditor.setLineWrap(true);//activació rotura de línies
        jtxtaEditor.setWrapStyleWord(true);//rotura entre paraules
        jscrpaneEditor.setViewportView(jtxtaEditor);//Assign barres a textarea
        getContentPane().add(jscrpaneEditor);
        jscrpaneEditor.setBounds(0, 36, 492, 200);
        addWindowListener(new WindowAdapter() {

            @Override
            public void windowOpened(WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
    }

    private void formWindowOpened(WindowEvent evt) {
        jtxtaEditor.requestFocus();
    }
    public static void main(String[] args) {
        new Editor().setVisible(true);
    }
}
