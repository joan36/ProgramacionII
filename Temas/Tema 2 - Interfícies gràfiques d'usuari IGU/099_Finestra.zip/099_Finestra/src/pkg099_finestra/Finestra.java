/*
 * Exemple de creació d'una finestra amb Swing
 *
 * Descriu un objecte derivat de la classe JFrame, aquest codi és una estructura
 * vàlida per cualsevol programa que mostri les seves dades en una finestra
 * principal
 *
 * La classe Finestra hereta de JFrame tots els seus mètodes a més de
 * initComponents i de exitForm
 *
 * initComponents: invoca al WindowListener per poder respondre als
 * esdeveniments de finestre com per exemple tancar-la
 *
 * exitForm: quan es tanca la finestra s'invoca aquest mètode i s'acaba
 * l'aplicació
 */
package pkg099_finestra;

/**
 *
 * @author miquelmascarooliver
 */
public class Finestra extends javax.swing.JFrame {

    public Finestra() {
        this.setSize(300, 200);
        setTitle("Finestra");
        initComponents();
    }

    private void initComponents() {
        addWindowListener(new java.awt.event.WindowAdapter() {

            @Override
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });
    }

    private void exitForm(java.awt.event.WindowEvent evt) {
        System.exit(0);
    }

    public static void main(String[] args) {
        new Finestra().setVisible(true);
    }
}
