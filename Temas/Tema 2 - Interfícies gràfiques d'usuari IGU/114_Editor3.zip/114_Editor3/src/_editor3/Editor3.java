/*
 * Programa que simula el comportament d'un editor text senzill per exemplificar
 * els menús i les barres d'eines de swing
 * En aquesta versió s'han afegit els botons amb icones i la seleccio i
 * deselecció d'opcions de menú
 */
package _editor3;

/**
 *
 * @author miquelmascarooliver
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

public class Editor3 extends JFrame {

    private JMenuBar jmbarEditor;
    private JMenu jmnuFitxer;
    private JMenu jmnuEdicio;
    private JMenuItem jmItemSortir;
    private JMenuItem jmItemAferrar;
    private JMenuItem jmItemCopiar;
    private JToolBar jtbarEditor;
    private JButton jbtAferrar;
    private JButton jbtCopiar;
    private JScrollPane jscrpaneEditor;
    private JTextArea jtxtaEditor;

    public Editor3() {
        setSize(500, 300);
        setTitle("Editor");
        setDefaultCloseOperation(Editor3.EXIT_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        jmbarEditor = new JMenuBar();
        jmnuFitxer = new JMenu();
        jmnuEdicio = new JMenu();
        jmItemSortir = new JMenuItem();
        jmItemAferrar = new JMenuItem();
        jmItemCopiar = new JMenuItem();
        jtbarEditor = new JToolBar();
        jbtAferrar = new JButton();
        jbtCopiar = new JButton();
        jscrpaneEditor = new JScrollPane();
        jtxtaEditor = new JTextArea();

        getContentPane().setLayout(null);

        getContentPane().add(jmbarEditor);
        getContentPane().add(jtbarEditor);

        jmItemSortir.setText("Sortir");
        jmItemSortir.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evt) {
                jmItemSortirActionPerformed(evt);
            }
        });
        jmItemAferrar.setText("Aferrar");
        jmItemAferrar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evt) {
                jmItemAferrarActionPerformed(evt);
            }
        });
        jmItemCopiar.setText("Copiar");
        jmItemCopiar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evt) {
                jmItemCopiarActionPerformed(evt);
            }
        });


        jmnuFitxer.setText("Fitxer");
        jmnuFitxer.add(jmItemSortir);
        jmnuEdicio.setText("Edició");
        jmnuEdicio.add(jmItemAferrar);
        jmnuEdicio.add(jmItemCopiar);
//Per seleccionar i deseleccionar items de menú
        jmnuEdicio.addMenuListener(new MenuListener() {
            public void menuSelected (MenuEvent evt) {
                jmnuEdicioSelected(evt);
            }

            public void menuDeselected(MenuEvent me) {
            }

            public void menuCanceled(MenuEvent me) {
            }
        });
        jmbarEditor.add(jmnuFitxer);
        jmbarEditor.add(jmnuEdicio);

        setJMenuBar(jmbarEditor);

        jbtAferrar.setIcon(new ImageIcon("icones/paste.png"));
        jbtAferrar.setBorderPainted(false);
        jbtAferrar.setToolTipText("Aferrar");
        jbtAferrar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evt) {
                jmItemAferrarActionPerformed(evt);
            }
        });
        jbtCopiar.setIcon(new ImageIcon("icones/copy.png"));
        jbtCopiar.setBorderPainted(false);
        jbtCopiar.setToolTipText("Copiar");
        jbtCopiar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evt) {
                jmItemCopiarActionPerformed(evt);
            }
        });
        jtbarEditor.add(jbtAferrar);
        jtbarEditor.add(jbtCopiar);

        jtbarEditor.setBounds(0, 0, 492, 36);

        jscrpaneEditor.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);//Sempre sortirà
        jtxtaEditor.setLineWrap(true);//activació rotura de línies
        jtxtaEditor.setWrapStyleWord(true);//rotura entre paraules
        jscrpaneEditor.setViewportView(jtxtaEditor);//Assign barres a textarea
        getContentPane().add(jscrpaneEditor);
        jscrpaneEditor.setBounds(0, 36, 492, 200);
        addWindowListener(new WindowAdapter() {

            @Override
            public void windowOpened(WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
    }

    private void formWindowOpened(WindowEvent evt) {
        jtxtaEditor.requestFocus();
    }

    private void jmItemSortirActionPerformed(ActionEvent evt) {
        System.exit(0);
    }

    private void jmItemAferrarActionPerformed(ActionEvent evt) {
        jtxtaEditor.paste();
    }

    private void jmItemCopiarActionPerformed(ActionEvent evt) {
        jtxtaEditor.copy();
    }

    private void jmnuEdicioSelected(MenuEvent evt) {
        boolean textSeleccionat = jtxtaEditor.getSelectedText() != null;
        jmItemCopiar.setEnabled(textSeleccionat);
    }

    public static void main(String[] args) {
        new Editor3().setVisible(true);
    }
}
