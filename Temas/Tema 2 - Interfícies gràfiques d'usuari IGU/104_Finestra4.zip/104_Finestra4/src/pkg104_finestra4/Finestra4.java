/*
 * Exemple de creació d'una finestra amb Swing
 *
 * Descriu una finestra com un frame, un panell, una etiqueta i un botó. El
 * constructor contrueix el panell i els seus dos components.
 *
 * El mètode construirpanell crea una etiqueta, el botón amb l'acció associada,
 * finalment construeix el panell i li afegeix els components.
 *
 * El mètode construir finestra la crea amb unes opcions de visualització
 */
package pkg104_finestra4;

/**
 *
 * @author miquelmascarooliver
 */
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.*;

public class Finestra4 {

    private JFrame frame;
    private JPanel p;
    private JLabel etiqueta;
    private JButton boto;

    public Finestra4() {
        construirPanell();
        construirFinestra();
    }

    private void construirPanell() {
        etiqueta = new JLabel();
        etiqueta.setText("Hola món");
        etiqueta.setHorizontalAlignment(SwingConstants.CENTER);
        etiqueta.setFont(new Font("courier", 1, 20));
        boto = new JButton();
        boto.setToolTipText("Pitja el botó");
        boto.setMnemonic('C');
        boto.setText("Fes click aquí");
        boto.setMaximumSize(new Dimension(100, 20));
//        boto.setBounds(42, 90, 204, 30);
        boto.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accioBoto(evt);
            }
        });
//        p = new JPanel(new FlowLayout());
//        p = new JPanel();
//        p.add(etiqueta);
//        p.add(boto);


    }

    private void accioBoto(java.awt.event.ActionEvent evt) {
        float vermell = (float) Math.random();
        float verd = (float) Math.random();
        float blau = (float) Math.random();
        etiqueta.setForeground(new java.awt.Color(vermell, verd, blau));
        etiqueta.setText("Som aquí!!!");

    }

    private void construirFinestra() {
        frame = new JFrame("Finestra");
//        frame.add(p);
//        frame.setLayout(new BorderLayout());
//        frame.add(etiqueta, BorderLayout.CENTER);
//        frame.add(boto, BorderLayout.SOUTH);
        frame.setLayout(new GridLayout(2,1));
        frame.add(etiqueta);
        frame.add(boto);
        frame.pack();
        frame.setSize(500, 500);
//        frame.setResizable(false);
        frame.setMinimumSize(new Dimension(150, 100));
        frame.setVisible(true);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        Finestra4 f = new Finestra4();
    }
}
