/*
 * Programa que converteix els graus centígrads a fahrenheit
 * Exemple de l'us de els camps de text
 */
package pkg108_conversiograus3;

/**
 *
 * @author miquelmascaro
 */
import java.awt.event.*;
import javax.swing.*;

public class ConversioGraus3 extends JFrame {

    private JLabel jlbGrausC;
    private JTextField jtfGrausC;
    private JLabel jlbGrausF;
    private JTextField jtfGrausF;
    private JButton jbtAcceptar;
    private Object objJTextField;
    //Per controlar a quina caixa de text s'ha escrit usam aquest objecte

    public ConversioGraus3() {
        setSize(300, 200);
        setTitle("Conversió temperatures");
        initComponents();
    }

    private void initComponents() {
        jlbGrausC = new JLabel();
        jtfGrausC = new JTextField();
        jlbGrausF = new JLabel();
        jtfGrausF = new JTextField();
        jbtAcceptar = new JButton();

        getContentPane().setLayout(null);
        addWindowListener(new WindowAdapter() {
            //Esdeveniment de finestra oberta per controlar el focus

            @Override
            public void windowOpened(WindowEvent evt) {
                formWindowOpened(evt);
            }

            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }
        });

        jlbGrausC.setText("Graus centigrads");
        getContentPane().add(jlbGrausC);
        jlbGrausC.setBounds(12, 28, 116, 16);
        jtfGrausC.setText("0.00");
        jtfGrausC.setHorizontalAlignment(SwingConstants.RIGHT);
        getContentPane().add(jtfGrausC);
        jtfGrausC.setBounds(132, 28, 144, 20);
        jlbGrausF.setText("Graus fahrenheit");
        getContentPane().add(jlbGrausF);
        jlbGrausF.setBounds(12, 68, 116, 24);
        jtfGrausF.setText("32.00");
        jtfGrausF.setHorizontalAlignment(SwingConstants.RIGHT);
        getContentPane().add(jtfGrausF);
        jtfGrausF.setBounds(132, 72, 144, 20);
        jbtAcceptar.setText("Acceptar");
        jbtAcceptar.setMnemonic('A');
        getRootPane().setDefaultButton(jbtAcceptar);//botó per omisió intro
        getContentPane().add(jbtAcceptar);
        jbtAcceptar.setBounds(132, 120, 144, 24);

        //Per controlar els esdeveniments KeyEvent a les finestres de text
        KeyAdapter kl = new KeyAdapter() {

            @Override
            public void keyTyped(KeyEvent evt) {
                jtfGrausKeyTyped(evt);
            }
        };
        jtfGrausC.addKeyListener(kl);
        jtfGrausF.addKeyListener(kl);

        //Per controlar el click sobre Acceptar
        jbtAcceptar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evt) {
                jbtAcceptarActionPerformed(evt);
            }
        });

        //Per controlar els focus dels objectes caixes de text
        FocusAdapter fl = new FocusAdapter() {

            @Override
            public void focusGained(FocusEvent evt) {
                jtfGrausFocusGained(evt);
            }
        };
        jtfGrausC.addFocusListener(fl);
        jtfGrausF.addFocusListener(fl);
    }

    //Assigna el focus a la caixa de text dels graus centígrads
    private void formWindowOpened(WindowEvent evt) {
        jtfGrausC.requestFocus();
    }

    private void exitForm(WindowEvent evt) {
        System.exit(0);
    }

    private void jtfGrausKeyTyped(KeyEvent evt) {
        objJTextField = evt.getSource(); //objecte que ha produit l'esdeveniment
    }

    private void jtfGrausFocusGained(FocusEvent evt) {
        JTextField objEnfocat = (JTextField) evt.getSource();
        //getsource retorna un objecte i es fa la conversió a caixa de text
        objEnfocat.selectAll();
    }

    private void jbtAcceptarActionPerformed(ActionEvent evt) {
        try {
            double gr;
            //Si el text s'ha escrit a la caixa de graus centigrads
            if (objJTextField == jtfGrausC) {
                gr = Double.parseDouble(jtfGrausC.getText()) * 9.0 / 5.0 + 32.0;
                String s = String.format("%.2f", gr); //arrodoneix 2 decimals
                jtfGrausF.setText(s);
            }
            //Si s'ha escrit a la caixa de graus fahrenheit
            if (objJTextField == jtfGrausF) {
                gr = (Double.parseDouble(jtfGrausF.getText()) - 32.0) * 5.0 / 9.0;
                String s = String.format("%.2f", gr);
                jtfGrausC.setText(s);
            }
        } catch (NumberFormatException e) {
            jtfGrausC.setText("0.00");
            jtfGrausF.setText("32.00");
        }
    }

    public static void main(String[] args) {
        try { //Control de l'aspecte
            UIManager.setLookAndFeel(
                    UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {
            System.out.println("No s'ha establert el look desitjat: " + e);
        }
        new ConversioGraus3().setVisible(true);
    }
}
