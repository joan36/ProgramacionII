/*
 * Exemple de creació d'una finestra amb Swing
 *
 * Descriu un objecte derivat de la classe JFrame, aquest codi és una estructura
 * vàlida per cualsevol programa que mostri les seves dades en una finestra
 * principal
 *
 * La classe Finestra hereta de JFrame tots els seus mètodes a més de
 * initComponents i de exitForm
 *
 * initComponents: invoca al WindowListener per poder respondre als
 * esdeveniments de finestre com per exemple tancar-la
 *
 * exitForm: quan es tanca la finestra s'invoca aquest mètode i s'acaba
 * l'aplicació
 *
 * Cream una etiqueta i un botó: És crea l'objecte i s'afegeix al panell arrel
 * Una de les característiques del botó és el seu escoltador que detectarà
 * clicks sobre ell, en aquest cas executarà el mètode:
 *
 * jBtSaludoActionPerformed: consisteix en anar calculant colors aleatoris
 * que s'assignen a l'etiqueta
 */
package pkg103_finestra3;

/**
 *
 * @author miquelmascarooliver
 */
public class Finestra3 extends javax.swing.JFrame {

    private javax.swing.JLabel jEtSaludo;
    private javax.swing.JButton jBtSaludo;

    public Finestra3() {
        setSize(300, 200);
        setTitle("Finestra");
        initComponents();
    }

    private void initComponents() {
        jEtSaludo = new javax.swing.JLabel(); // Es crea l'objecte
        jBtSaludo = new javax.swing.JButton(); // Es crea l'objecte
        getContentPane().setLayout(null);
        addWindowListener(new java.awt.event.WindowAdapter() {

            @Override
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });
        jEtSaludo.setText("Hola món");
        jEtSaludo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jEtSaludo.setFont(new java.awt.Font("courier", 1, 20));
        getContentPane().add(jEtSaludo); // s'afegeix l'etiqueta al panell arrel
        jEtSaludo.setBounds(42, 36, 204, 30);
        jBtSaludo.setToolTipText("Pitja el botó");
        jBtSaludo.setMnemonic('C');//alt + c per activar el botó
        jBtSaludo.setText("Fes click aquí");
        //Escoltador dels esdeveniments del botó
        jBtSaludo.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtSaludoActionPerformed(evt);
            }
        });
        getContentPane().add(jBtSaludo); // s'afegeix el botó al panell arrel
        jBtSaludo.setBounds(42, 90, 204, 30);
    }

    private void exitForm(java.awt.event.WindowEvent evt) {
        System.exit(0);
    }

    private void jBtSaludoActionPerformed(java.awt.event.ActionEvent evt) {
        float vermell = (float) Math.random();
        float verd = (float) Math.random();
        float blau = (float) Math.random();
        jEtSaludo.setForeground(new java.awt.Color(vermell, verd, blau));
        jEtSaludo.setText("Som aquí!!!");

    }

    public static void main(String[] args) {
        try { //Control de l'aspecte
            javax.swing.UIManager.setLookAndFeel(
                    javax.swing.UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {
            System.out.println("No s'ha establert el look desitjat: " + e);
        }
        new Finestra3().setVisible(true);
    }
}
