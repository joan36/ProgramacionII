/*
 * Exemple d'us de la classe Stack per definir una pila de xifres romanes
 *
 * Mitjançant un menú senzill es gestionen les opcions d'afegir i llevar
 * elements, de buidar tota la pila i de mirar quin és el de damunt.
 *
 * Observi's la similitud entre la classe Stack i la nostra pila genèrica dels
 * exemples anteriors
 */
package _pilagenerica3;

/**
 *
 * @author miquelmascarooliver
 */
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.EmptyStackException;
import java.util.Stack;

public class PilaGenerica3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Stack<XifraRomana> pilaRomans = new Stack<XifraRomana>();
        boolean sortir = false;
        int opcio = 0;
        while (!sortir) {
            menu();
            opcio = llegirEnter("\n\n\tInserir opció: ");
            switch (opcio) {
                case 1:
                    try {
                        int x = llegirEnter("Insereix el valor de la xifra a"
                                + " posar: ");
                        XifraRomana xr = new XifraRomana(x);
                        pilaRomans.push(xr);
                    } catch (XifraRomana.nombreNoRepresentable e2) {
                        System.out.println("ERROR: El valor inserit no és"
                                + "representable en xifres romanes");
                    }
                    break;
                case 2:
                    try {
                        XifraRomana xr = pilaRomans.pop();
                        System.out.println("La xifra treta és: " + xr);
                    } catch (EmptyStackException e) {
                        System.out.println("ERROR: " + e.getMessage());
                    }
                    break;
                case 3:
                    int i = 1;
                    while (!pilaRomans.empty()) {
                        try {
                            System.out.println("Element " + i + ": "
                                    + pilaRomans.pop());
                            i++;
                        } catch (EmptyStackException e) {
                            System.out.println("ERROR: " + e.getMessage());
                        }
                    }
                    System.out.println("La pila està buida");
                    break;
                case 4:
                    try {
                        XifraRomana xr = pilaRomans.peek();
                        System.out.println("La xifra de d'alt és: " + xr);
                    } catch (EmptyStackException e) {
                        System.out.println("ERROR: " + e.getMessage());
                    }
                    break;
                case 0:
                    sortir = true;
                    break;
            }
        }
    }

    private static void menu() {
        System.out.println("\n\nPila de xifres romanes");
        System.out.println("\n\t1. Posar una xifra");
        System.out.println("\t2. Treure una xifra");
        System.out.println("\t3. Treure totes les xifres");
        System.out.println("\t4. Mirar l'ement de d'alt sense treure'l");
        System.out.println("\t0. Sortir");
    }

    private static int llegirEnter(String msg) {
        int x = 0;
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            System.out.print(msg);
            String s = in.readLine();
            x = Integer.parseInt(s);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return x;
    }
}
