/*
 * Interfici per a comparar dos objectes amb dos mètodes:
 * compara: torna -1 si l'objecte és menor al que es passa per paràmetre, 0 si
 * son iguals i 1 si és major.
 * menorQue: torna vertader si l'objecte és menor que el que passa per paràmetre
 */
package pilagenerica4;

public interface Comparador {

    int compara(Comparador item);

    boolean menorQue(Comparador item);
}
