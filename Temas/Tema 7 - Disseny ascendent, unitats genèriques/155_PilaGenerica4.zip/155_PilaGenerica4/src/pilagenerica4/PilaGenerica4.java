/*
 * Exemple d'us de la pila genèrica per definir una pila de xifres romanes,
 * Aquesta pila no permet apilar elements més grossos sobre element més petits
 *
 * Mitjançant un menú senzill es gestionen les opcions d'afagir i llevar
 * elements i de buidar tota la pila.
 *
 * Observi's la independència de la pila amb l'E/S i la interacció entre la
 * classe xifra romana i la classe pila.
 */
package pilagenerica4;

/**
 *
 * @author miquelmascarooliver
 */
import java.io.*;

public class PilaGenerica4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pila<XifraRomana> pilaRomans = new Pila<XifraRomana>(5);
        boolean sortir = false;
        int opcio = 0;
        while (!sortir) {
            menu();
            opcio = llegirEnter("\n\n\tInserir opció: ");
            switch (opcio) {
                case 1:
                    try {
                        int x = llegirEnter("Insereix el valor de la xifra a"
                                + " posar: ");
                        XifraRomana xr = new XifraRomana(x);
                        pilaRomans.posar(xr);
                    } catch (Pila.PilaPlena e1) {
                        System.out.println(e1.getMessage());
                    } catch (XifraRomana.nombreNoRepresentable e2) {
                        System.out.println("ERROR: El valor inserit no és"
                                + "representable en xifres romanes");
                    } catch (Pila.NoApilable e3) {
                        System.out.println(e3.getMessage());
            }
                    break;
                case 2:
                    try {
                        XifraRomana xr = pilaRomans.treure();
                        System.out.println("La xifra treta és: " + xr);
                    } catch (Pila.PilaBuida e) {
                        System.out.println("ERROR: " + e.getMessage());
                    }
                    break;
                case 3:
                    int i = 1;
                    while (!pilaRomans.esBuida()) {
                        try {
                            System.out.println("Element " + i + ": "
                                    + pilaRomans.treure());
                            i++;
                        } catch (Pila.PilaBuida e) {
                            System.out.println("ERROR: " + e.getMessage());
                        }
                    }
                    System.out.println("La pila està buida");
                    break;
                case 0:
                    sortir = true;
                    break;
            }
        }
    }

    private static void menu() {
        System.out.println("\n\nPila de xifres romanes");
        System.out.println("\n\t1. Posar una xifra");
        System.out.println("\t2. Treure una xifra");
        System.out.println("\t3. Treure totes les xifres");
        System.out.println("\t0. Sortir");
    }

    private static int llegirEnter(String msg) {
        int x = 0;
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            System.out.print(msg);
            String s = in.readLine();
            x = Integer.parseInt(s);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return x;
    }
}
