/*
 * Classe XifraRoma que permet el tractament de xifres amb aquest format
 *
 * Una xifra romana és una cadena de caràcters que la representa s i un valor n.
 * Per escriures xidres romanes és poden usar els caràcters de sym amb una
 * sèrie de convencions.
 *
 * Hi ha dos errors possibles que afecten en aquest tipus de dades que la cadena
 * de símbols tengui caracters no permesos o que no segueixi les regles
 * determinades i que el valor del nombre que es representa estigui fora dels
 * límits que són 0 i 39999
 *
 * Es defineixen tres constructors: el primer és la xifra romana 0, el segon
 * construir una xifra romana a partir de la cadena de caràcters i el tercer
 * a partir d'un enter. En el segon es mira si la cadena és correcte i si ho és
 * es fan les assignacions, en el tercer es mira si l'enter està entre els
 * límits i si ho està es cerca la seva representació, descomposant la xifra en
 * dígits i per cada un depenent de la magnitud es troba la seva representació
 * en xifres romanes.
 *
 * El mètode toString mostra la cadena de la xifra romana
 *
 * El mètode valorDe mostra el valor de la xifra romana
 *
 * El mètode esCorrecte comprova la validesa d'una cadena com a xifra romana,
 * per això defineix la taula d'estats de l'autòmat finit que descriu les
 * possibles representacions de xifres romanes, fa una cerca dins la cadena d'un
 * estat erròni i si no el troba conclou que la xifra és correcte.
 *
 * El mètode simbol és usat pel mèdode esCorrecte i el que fa és per un
 * determinat dígit romà retornar la posició que ocupa dins sym o un altre si no
 * hi pertany.
 *
 * El mètode valorDe retorna el valor d'una cadena que representa una xifra
 * romana correcte. Per això va mirant parelles de caràcters sumant si el
 * següents és menor o igual o fent la resta en cas contrari.
 *
 * El mètode valor dígit és usat pel valorDe i el que fa és retornar el valor
 * d'un determinat dígit romà, per això aprofita la característica del romans de
 * cada valor de simbol es calcula multiplicant per 5 o per 2 depenet de si és
 * parell o imparell.
 *
 * El mètode repRoma és el que donat un nombre i la seva magnitud genera una
 * cadena de caracters amb els símbols romans que el representen, per això té
 * en compte la forma que tenen els dígits romans de 0 a 9 independentment de la
 * magnitud i la descriu amb la taula tipus, llavors els caracters que descriuen
 * la xifra seràn els de la taula sym relacionats amb la tipus segons la
 * magnitud.
 */
package _pilagenerica2;

/**
 *
 * @author miquelmascarooliver
 */
public class XifraRomana {

    private int n;
    private String s;
    private static final String sym = "IVXLCDMFT";

    public static class xifraRomanaIncorrecta extends Exception {
    }

    public static class nombreNoRepresentable extends Exception {
    }

    public XifraRomana() {
        n = 0;
        s = "";
    }

    public XifraRomana (String cadena) throws xifraRomanaIncorrecta {
        if (!esCorrecte(cadena)) {
            throw new xifraRomanaIncorrecta();
        }       
        s = cadena;
        n = valorDe(cadena);
    }

    public XifraRomana (int n) throws nombreNoRepresentable {
        if (n < 0 || n > 39999) {
            throw new nombreNoRepresentable();
        }
        int ord = 4;
        int divi = 10000;
        int nr = n;
        s = "";
        while (ord >= 0) {
            int xifra = nr / divi;
            nr = nr % divi;
            s += repRoma(xifra, ord);
            ord--;
            divi /= 10;
        }
        this.n = n;
    }

    @Override
    public String toString() {
        return s;
    }

    public int valorDe() {
        return n;
    }

    private static boolean esCorrecte(String r) {
        final int estatInicial = 0;
        final int E = 25;
        final int[][] T = {
            // I  V  X  C  L   D   M   W   T   altres
            {1, 2, 6, 7, 11, 12, 16, 17, 21, E}, // 0
            {4, 5, 5, E, E, E, E, E, E, E}, // 1
            {3, E, E, E, E, E, E, E, E, E}, // 2
            {4, E, E, E, E, E, E, E, E, E}, // 3
            {5, E, E, E, E, E, E, E, E, E}, // 4
            {E, E, E, E, E, E, E, E, E, E}, // 5
            {1, 2, 9, 10, 10, E, E, E, E, E}, // 6
            {1, 2, 8, E, E, E, E, E, E, E}, // 7
            {1, 2, 9, E, E, E, E, E, E, E}, // 8
            {1, 2, 10, E, E, E, E, E, E, E}, // 9
            {1, 2, E, E, E, E, E, E, E, E}, //10
            {1, 2, 6, 7, 14, 15, 15, E, E, E}, //11
            {1, 2, 6, 7, 13, E, E, E, E, E}, //12
            {1, 2, 6, 7, 14, E, E, E, E, E}, //13
            {1, 2, 6, 7, 15, E, E, E, E, E}, //14
            {1, 2, 6, 7, E, E, E, E, E, E}, //15
            {1, 2, 6, 7, 11, 12, 19, 20, 20, E}, //16
            {1, 2, 6, 7, 11, 12, 18, E, E, E}, //17
            {1, 2, 6, 7, 11, 12, 19, E, E, E}, //18
            {1, 2, 6, 7, 11, 12, 20, E, E, E}, //19
            {1, 2, 6, 7, 11, 12, E, E, E, E}, //20
            {1, 2, 6, 7, 11, 12, 16, 17, 22, E}, //21
            {1, 2, 6, 7, 11, 12, 16, 17, 23, E}, //22
            {1, 2, 6, 7, 11, 12, 16, 17, E, E}, //23
            {E, E, E, E, E, E, E, E, E, E} // E
        };
        int estat = estatInicial;
        int i = 0;       
        while (estat != E && i < r.length()) {
            estat = T[estat][simbol(r.charAt(i))];
            i++;
        }
        return (estat != 0 && estat != E);
    }

    private static int simbol(char c) {
        final int altres = sym.length();
        int i = 0;
        while (i < sym.length() && sym.charAt(i) != c) {
            i++;
        }
        return i < sym.length() ? i : altres;
    }

    private static int valorDe(String r) {
        int s = 0;
        int i = 0;
        r += ' ';
        int vi = valorDigit(r.charAt(i));
        for (i = 0; r.charAt(i) != ' '; i++) {
            int vi1 = valorDigit(r.charAt(i + 1));
            if (vi >= vi1) {
                s += vi;
            } else {
                s -= vi;
            }
            vi = vi1;
        }
        return s;
    }

    private static int valorDigit(char c) {
        int v = 0;
        if (c != ' ') {
            int i = 0;
            v = 1;
            boolean Parell = true;
            while (c != sym.charAt(i)) {
                i++;
                Parell = !Parell;
                if (Parell) {
                    v *= 2;
                } else {
                    v *= 5;
                }
            }
        }
        return v;
    }

    private static String repRoma(int xifra, int ord) {
        String cadena = "";
        String tipus[] = new String[]{
            " ", "0 ", "00 ", "000 ", "01 ", "1 ", "10 ", "100 ", "1000 ",
            "02 "};
        int posord, i = 0;
        posord = ord * 2;
        while (tipus[xifra].charAt(i) != ' ') {
            if (tipus[xifra].charAt(i) == '0') {
                cadena = cadena + sym.charAt(posord);
            } else if (tipus[xifra].charAt(i) == '1') {
                cadena = cadena + sym.charAt(posord + 1);
            } else {
                cadena = cadena + sym.charAt(posord + 2);
            }
            i++;
        }
        return cadena;
    }
}
