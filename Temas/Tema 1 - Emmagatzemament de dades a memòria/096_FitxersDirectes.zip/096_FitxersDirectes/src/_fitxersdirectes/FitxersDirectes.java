/*
 * Exemple de fitxers directes
 *
 * El codi que segueix és simplement per veure les funcionalitats dels fitxers
 * directes. No implementa de forma correcte l'abstracció de dades, ni fa
 * tractament d'errors, la declaració de les variables s'ha fet tot local a cada
 * uns dels diferents mètodes que són:
 *
 * Creació d'un registre, sempre al final del fitxer
 * Recorregut seqüencial del fitxer
 * Cerca per posició d'un registre i
 * Recorregut amb filtrat de la informació
 *
 * Se suposen registres formats per tres camps: clau, nom i edat.
 */
package _fitxersdirectes;

/**
 *
 * @author miquelmascarooliver
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;

public class FitxersDirectes {

    public static void main(String[] args) {
        inserirRegistre();
        contingutFitxer();
        cercaRegistre();
        filtreEdat();
    }

    private static void inserirRegistre() {
        int clau;
        String nom;
        int edat;
        final int longExacta = 20;
        try {
            File arxiu = new File("directe.dat");
            RandomAccessFile f = new RandomAccessFile(arxiu, "rw");
            clau = llegirEnter("Clau: ");
            nom = llegirNom("Nom: ");
            edat = llegirEnter("Edat: ");
            if (nom.length() < longExacta) {
                for (int i = nom.length(); i < longExacta; i++) {
                    nom = nom + " ";
                }
            } else {
                nom = nom.substring(0, longExacta-1);
            }
            if (f.length() != 0) {
                f.seek(f.length());
            }
            f.writeInt(clau);
            f.writeChars(nom);
            f.writeInt(edat);
            f.close();
            System.out.println("REGISTRE INSERIT");
        } catch (Exception e) {
        }
    }

    private static void contingutFitxer() {
        int clau;
        String nom = "";
        int edat;
        final int longExacta = 20;
        // 2 bytes cada caracter string 4 bytes per cada enter
        final long midaReg = (longExacta * 2) + (2 * 4);
        try {
            File arxiu = new File("directe.dat");
            RandomAccessFile f = new RandomAccessFile(arxiu, "r");
            long numreg = f.length() / midaReg;
            for (int r = 0; r < numreg; r++) {
                clau = f.readInt();
                for (int i = 0; i < longExacta; ++i) {
                    nom += f.readChar();
                }
                edat = f.readInt();
                System.out.println("Clau: " + clau + " Nom: " + nom + " Edat: "
                        + edat);
                nom = "";
            }
            f.close();
        } catch (IOException e) {
        }
    }

    private static void cercaRegistre() {
        int clau;
        String nom = "";
        int edat;
        final int longExacta = 20;
        final long midaReg = (longExacta * 2) + (2 * 4);
        try {
            int n = llegirEnter("Registre a cercar per posicio: ");
            File arxiu = new File("directe.dat");
            RandomAccessFile f = new RandomAccessFile(arxiu, "rw");
            if (n * midaReg < f.length()) {
                f.seek(n * midaReg);
                clau = f.readInt();
                for (int i = 0; i < longExacta; ++i) {
                    nom += f.readChar();
                }
                edat = f.readInt();
                System.out.println("Clau: " + clau + " Nom: " + nom + " Edat: "
                        + edat);
            } else {
                System.out.println("El registre no hi és");
            }
            f.close();
        } catch (IOException e) {
        }
    }

    private static void filtreEdat() {
        int clau = 0;
        String nom = "";
        int edat = 0;
        final int longExacta = 20;
        final long midaReg = (longExacta * 2) + (2 * 4);
        try {
            File arxiu = new File("directe.dat");
            RandomAccessFile f = new RandomAccessFile(arxiu, "rw");
            int x = llegirEnter("Edat >= ");
            long numreg = f.length() / midaReg;
            for (int r = 0; r < numreg; r++) {
                clau = f.readInt();
                for (int i = 0; i < longExacta; ++i) {
                    nom += f.readChar();
                }
                edat = f.readInt();
                if (edat >= x) {
                    System.out.println("Clau: " + clau + " Nom: " + nom +
                            " Edat: " + edat);
                }
                nom = "";
            }
            f.close();
        } catch (IOException e) {
        }
    }

    private static int llegirEnter(String msg) {
        int x = 0;
        try {
            BufferedReader in = new BufferedReader
                    (new InputStreamReader(System.in));
            System.out.print(msg);
            String s = in.readLine();
            x = Integer.parseInt(s);
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return x;
    }

    private static String llegirNom(String msg) {
        String s = null;
        try {
            BufferedReader in = new BufferedReader
                    (new InputStreamReader(System.in));
            System.out.print(msg);
            s = in.readLine();
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return s;
    }
}
