package DefArticles;

/**
 * Classe que defineix el tipus d'actualització. Ha de ser public i és exportat
 * pel mètode getAct i pertant serà usat pel mètode que fa l'actualització
 * dels fitxers
 * @author miquelmascarooliver
 */

public enum TipusAct {

    /**
     *
     */
    ALTA,

    /**
     *
     */
    BAIXA,

    /**
     *
     */
    MODIFICACIO
}

