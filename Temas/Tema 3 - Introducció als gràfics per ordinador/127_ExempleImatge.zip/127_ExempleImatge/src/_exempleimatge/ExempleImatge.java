/*
 * Exemple de dibuix usant imatges
 *
 * Al programa principal cream el marc amb el panel que contindrà el gràfic 2D
 */
package _exempleimatge;

import javax.swing.*;

public class ExempleImatge extends JFrame {

    private PaperDibuix paper;


    public ExempleImatge() {

        this.setTitle("Riu");
        this.setDefaultCloseOperation(ExempleImatge.EXIT_ON_CLOSE);
        paper = new PaperDibuix();
        this.setSize(paper.getPreferredSize());
        this.setResizable(false);
        this.getContentPane().add(paper);
        this.pack();
    }
    public static void main(String[] args) {
        new ExempleImatge().setVisible(true);
    }
}