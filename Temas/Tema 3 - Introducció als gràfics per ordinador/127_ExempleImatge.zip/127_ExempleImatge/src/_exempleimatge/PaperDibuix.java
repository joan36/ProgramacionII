/*
 * Carrega una imatge d'un fitxer
 *
 * Usa l'instrucció drawImage de Graphics per pintar l'imatge al JPanel
 * Al constructor es llegix la imatge amb el mètode de imageio
 * El mètode getPreferredSize el que fa es retornar la
 * dimensió de la imatge
 */
package _exempleimatge;

/**
 *
 * @author miquelmascaro
 */
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

class PaperDibuix extends JPanel {

    private String fitxerImatge = "imatges/riu.jpg";
    private BufferedImage img;

    public PaperDibuix() {
        try {
            img = ImageIO.read(new File(fitxerImatge));
        } catch (IOException e) {
        }
    }

    @Override
    public void paintComponent(Graphics g) {
//        Graphics2D g2d = (Graphics2D) g;
//        g2d.drawImage(img, null, 0, 0);
        
        g.drawImage(img, 0, 0, null);
//        g.drawImage(img, 100, 100, 300, 20, 0, 0, 640, 480, this);
//        g.drawImage(img, 100, 100, 300, 300, 0, 0, img.getWidth(null), img.getHeight(null), null);
    }

    @Override
    public Dimension getPreferredSize() {
        if (img == null) {
            return new Dimension(100, 100);
        } else {
            return new Dimension(img.getWidth(null), img.getHeight(null));
        }
    }
}
