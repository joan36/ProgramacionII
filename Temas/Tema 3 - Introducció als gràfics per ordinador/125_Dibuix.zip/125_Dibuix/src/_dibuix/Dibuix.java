/*
 * Exemple de dibuix de primitives
 *
 * Al programa principal cream el marc amb el panel que contindrà el gràfic 2D
 */
package _dibuix;

import javax.swing.JFrame;

public class Dibuix extends JFrame {

    private PaperDibuix paper;

    public Dibuix() {
        this.setSize(500, 500 + 20);//+20 pel marc de la finestra
//        this.setUndecorated(true);//Lleva el marc de la finestra
        this.setResizable(false);
        this.setTitle("Dibuix de primitives");
        this.setDefaultCloseOperation(Dibuix.EXIT_ON_CLOSE);

        this.getContentPane().setLayout(null);
        
        paper = new PaperDibuix();
        this.getContentPane().add(paper);
//        this.add(paper);
        paper.setBounds(0, 0, 500, 500);
    }
    public static void main(String[] args) {
        new Dibuix().setVisible(true);
    }
}
