/*
 * Dins una repetició de 5 x 5 definirà smileys formats per una Ellipse2D
 * per la cara, dues més pels ulls i un Arc2D per la boca pintats dins un
 * Rectangle2D
 */
package _dibuix2;

/**
 *
 * @author miquelmascaro
 */
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JPanel;


class PaperDibuix extends JPanel {

    public static final int MAXX = 500, MAXY = 500;
    private final int COSTAT = MAXX / 5;

    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        int y = 0;
        for (int i = 1; i <= 5; i++) {
            int x = 0;
            for (int j = 1; j <= 5; j++) {
                Rectangle2D.Float r = new Rectangle2D.Float(x, y, COSTAT, COSTAT);
                float vermell = (float) Math.random();
                float verd = (float) Math.random();
                float blau = (float) Math.random();
                g2d.setColor(new Color(vermell, verd, blau));
                g2d.fill(r);
                Ellipse2D.Float c = new Ellipse2D.Float(x + 5, y + 5, COSTAT - 10, COSTAT - 10);
                g2d.setColor(Color.YELLOW);
                g2d.fill(c);
                g2d.setColor(Color.BLACK);
                g2d.draw(c);
                Arc2D.Float a = new Arc2D.Float(x + 12, y, 75, 75, 225, 90, Arc2D.OPEN);
                g2d.draw(a);
                Ellipse2D.Float u1 = new Ellipse2D.Float(x + 25, y + 30, 10, 20);
                g2d.fill(u1);
                Ellipse2D.Float u2 = new Ellipse2D.Float(x + 65, y + 30, 10, 20);
                g2d.fill(u2);
                x += COSTAT;
            }
            y += COSTAT;
        }
        String s = "Smile!";
        g2d.setFont(new Font("arial",1,150));
        g2d.drawString(s, 25, MAXY + 140);
    }
}
