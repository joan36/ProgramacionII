/*
 * Exemple de dibuix de primitives
 *
 * Al programa principal cream el marc amb el panel que contindrà el gràfic 2D
 */
package _dibuix2;

import javax.swing.JFrame;

public class Dibuix2 extends JFrame {

    private PaperDibuix paper;


    public Dibuix2() {
        this.setSize(PaperDibuix.MAXX, PaperDibuix.MAXY + 200);
        this.setResizable(false);
        this.setTitle("Smileys");
        this.setDefaultCloseOperation(Dibuix2.EXIT_ON_CLOSE);
        paper = new PaperDibuix();
        this.getContentPane().add(paper);
    }
    public static void main(String[] args) {
        new Dibuix2().setVisible(true);
    }
}