/*
 * Programa que defineix un tauler d'escacs dins un marc i posa vuit reines
 * on indica l'usuari
 *
 */
package escacs5;

/**
 *
 * @author miquelmascaro
 */
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.*;

public class Escacs5 extends JFrame implements MouseListener {

    Tauler tauler;
    int numReines = 0;

    public Escacs5() {
        super("Joc de les reines");
        tauler = new Tauler();
        tauler.addMouseListener(this);
//        tauler.Posa(Pesa.REINAN, 0, 3);
//        tauler.Posa(Pesa.REINAN, 1, 6);
//        tauler.Posa(Pesa.REINAN, 2, 2);
//        tauler.Posa(Pesa.REINAN, 3, 7);
//        tauler.Posa(Pesa.REINAN, 4, 1);
//        tauler.Posa(Pesa.REINAN, 5, 6);
//        tauler.Posa(Pesa.REINAN, 6, 0);
//        tauler.Posa(Pesa.REINAN, 7, 5);
        this.getContentPane().add(tauler);
        this.setSize(tauler.getPreferredSize());
        this.pack();
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        Escacs5 esc = new Escacs5();
        esc.setVisible(true);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mousePressed(MouseEvent e) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        int x = 0, y = 0, i, j = 0;
        if (e.getButton() == MouseEvent.BUTTON1 && numReines < 8) {
            x = e.getX();
            y = e.getY();
            boolean trobat = false;
            for (i = 0; i < Tauler.DIMENSIO && !trobat; i++) {
                for (j = 0; j < Tauler.DIMENSIO && !trobat; j++) {
                    trobat = tauler.dinsCasella(i, j, x, y);
                }
            }
            i--;
            j--;
            System.out.println("Click a: " + i + ", " + j);
            if (!tauler.isOcupat(i, j)) {
                tauler.Posa(Pesa.REINAN, i, j);
                numReines++;
            } else {
                Toolkit.getDefaultToolkit().beep();
                tauler.buida(i, j);
                numReines--;
            }
//            tauler.repaint();
            tauler.paintImmediately(tauler.getRectangle(i, j));
            if (numReines == 8) {
                Toolkit.getDefaultToolkit().beep();
                ImageIcon icon = new ImageIcon("peces/cavallN.png");
                JOptionPane.showMessageDialog(null, "8 Reines al tauler!",
                        "Victoria!", JOptionPane.INFORMATION_MESSAGE, icon);
            }
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseExited(MouseEvent e) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
