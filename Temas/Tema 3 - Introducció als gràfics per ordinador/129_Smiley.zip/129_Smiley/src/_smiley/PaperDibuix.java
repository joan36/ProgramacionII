package _smiley;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.*;
import java.util.Random;
import javax.swing.JPanel;
/**
 * PaperDibuix és una classe que extén la funcionalitat de JPanell.
 * Senzillament s'encarrega de visualitzar un 'smiley' de color groc.
 *
 * La classe està preparada per respondre als esdeveniments de la rata.
 * Si es pica el botó dret o l'esquerra el corresponent ull es tanca i es
 * torna obrir en amollar el botó.
 * Si es pica el botó central o la roda de la rata aleshores la boca es gira
 * Si es roda la roda de la rata la boca tremola
 *
 * @version 2011/03/11
 */
public class PaperDibuix extends JPanel implements MouseListener,
                                                   MouseMotionListener,
                                                   MouseWheelListener {
    // Per caracteritzar els ulls
   private boolean [] obert;
   private static final int esquerra = 0;
   private static final int dret     = 1;
   // Per caracteritzar la boca
   private static final int contenta = 0;
   private static final int trista   = 1;
   private static final int nervis   = 2;
   private int boca;
   private double alpha;  // angle per quan s'hagi de posar la boca amb nervis
   private double factor; // modificador de la boca amb nervis

   private Random rnd; // per generar valors aleatoris

    @SuppressWarnings("LeakingThisInConstructor")
   public PaperDibuix() {
       // Crear un generador de valors aleatoris
       rnd = new Random(System.nanoTime());
       // Determinar aleatòriament un angle inicial per quan s'hagi de posar
       // la boca amb nervis.
       alpha = rnd.nextDouble();
       // Valors per defecte: Boca contenta, ulls oberts
       boca = contenta;
       obert = new boolean[2];
       obert[esquerra] = true;
       obert[dret] = true;

       // Declarar l'interés pels esdeveniments propis de la rata
       this.addMouseListener(this);
       this.addMouseMotionListener(this);
       this.addMouseWheelListener(this);
   }

   /*
    * A continuació es declaren una sèrie de constants que permeten fixar les
    * dimensions de la finestra i de la forma de la figura a dibuixar. Es cerca
    * la propocionalitat de la figura en base a les dimensions de la finestra.
    * Hi ha una certa component empírica d'assaig i error fins trobar les
    * proporcions que es puguin considerar adequades.
    */
   private static final int ampleFinestra = 640,
                              altFinestra = 480;
   // Mesura de la cara
   private static final int diametreCara = 400,
                            xBaseCara = (ampleFinestra - diametreCara) / 2,
                            yBaseCara = (altFinestra - diametreCara) / 2;
   // Els ulls
   // Ulls a un 30% del costat i un 25% d'adalt
   private static final double posicioHRelativaUll = 0.3,
                               posicioVRelativaUll = 0.25;
   private static final int    ampleUll = diametreCara / 20,
                                 altUll = diametreCara / 10,
                               xUllEsquerra = xBaseCara
                                    + (int)(posicioHRelativaUll * diametreCara)
                                    - ampleUll/2,
                               xUllDret = xBaseCara
                                    + (int)((1.0 - posicioHRelativaUll)
                                             * diametreCara)
                                    - ampleUll/2,
                               yUlls  = yBaseCara
                                    + (int)(posicioVRelativaUll * diametreCara),
                               oberturaUllTancat = 180,
                               angleUllTancat = 180;
   // La boca
   // La boca a un 15% del costat
   private static final double posicioRelativaBoca = 0.15;
   private static final int xBoca = xBaseCara
                                    + (int)(posicioRelativaBoca * diametreCara),
                            yBocaC = yBaseCara
                                    + (int)(posicioRelativaBoca * diametreCara),
                            yBocaT = yBaseCara + diametreCara - 2*yBocaC,
                            diametreBoca = (int)((1 - 2* posicioRelativaBoca)
                                                * diametreCara),
                            angleBocaContenta = 200,
                            angleBocaTrista = 20,
                            oberturaBoca = 140;
   // La boca amb nervis
   // ordenada de l'altura mitjana de la boca amb nervis
   private static final int baseBoca = yBocaT + (yBocaT-yBocaC)/2,
                                 alt = 20; // desviaci√≥ m√†xima des de baseBoca;
   // nombre de passes(bocinets) per dibuixar la boca amb nervis
   private static final int passes = 100;
   private static final double baseDelta = 8.0 * Math.PI / passes;

    /**
     * Definir la dimensió del panell
     *
     * @return la dimensió, fixa, sempre la mateixa.
     */
   public Dimension getPreferredSize() {
       return new Dimension(ampleFinestra, altFinestra);
   }

   /**
    * Mètode que s'encarrega de dibuixar al panell. Sempre dibuixa el mateix.
    * Aquest mètode és invocat automàticament quan la màquina virtual de java
    * determina que la finestra ha de ser redibuixada.
    *
    * @param g el context gràfic on dibuixar.
    */
    @Override
   public void paint(Graphics g) {
       super.paint(g);
       // El color de dibuix és groc.
       g.setColor(Color.YELLOW);
       // Dibuixar un √≥val inscri  g.setColor(Color.YELLOW);t a un rectangle de costats igual (√©s a dir
       // un quadrat, l'oval en realitat serà un cercle.
       // S'ha fet un c√†lcul aproximat de manera que el cercle quedi centrat
       // a la finestra i tengui un di√†metre de diametraCara p√≠xels.
       g.fillOval(xBaseCara, yBaseCara, diametreCara, diametreCara);

       // Canviar el color de dibuix, ara és negre
       g.setColor(Color.BLACK);
       g.drawOval(xBaseCara, yBaseCara, diametreCara, diametreCara);
       // Dibuixar dos òvals que seran els ulls
       if (obert[esquerra])
           g.fillOval(xUllEsquerra, yUlls, ampleUll, altUll);
       else
           g.drawArc(xUllEsquerra, yUlls, ampleUll, altUll,
                    angleUllTancat, oberturaUllTancat);
       if (obert[dret])
           g.fillOval(xUllDret, yUlls, ampleUll, altUll);
       else
           g.drawArc(xUllDret, yUlls, ampleUll, altUll,
                     angleUllTancat, oberturaUllTancat);

       // Dibuixar la boca.
       if (boca == contenta) // boca cóncava
           g.drawArc(xBoca, yBocaC, diametreBoca, diametreBoca,
                     angleBocaContenta, oberturaBoca);
       else if (boca == trista) // boca convexa
           g.drawArc(xBoca, yBocaT, diametreBoca, diametreBoca,
                     angleBocaTrista, oberturaBoca);
       else { // if (boca == nervis) // boca oscil·lant
           // Es dibuixarà la boca com una linia ondulant. Per fer-ho es ferà
           // ús de la funció matemàtica sinus.
           // El procés de dibuix serà anar dibuixant segments de recta
           // consecutius i de tamany petit.
           int x0 = xBoca, y0;   // coordenades per anar
           double x, y;          // dibuixant la boca

           double incr = (double)diametreBoca/passes;// augment del valor de les
                                                     // abcises per a cada passa
           // augment de l'angle per calcular el sinus. factor fa que delta
           // sigui positiu o negatiu.
           double delta =  baseDelta * factor;

           // valors inicials
           alpha = alpha + rnd.nextDouble(); // fa el 'moviment' més irregular
           // Calcular el punt (x0,y0), x0, ja és conegut. Falta calcular
           // l'altura y0, que es correspon amb el sinus d'alpha escalat
           // (multiplicat per alt) i desplaçat (se li suma baseBoca).
           y0 = (int)(baseBoca + alt * Math.sin(alpha));
           x = x0;  //valor inicial de x
           for (int i = 0; i < passes; i++) {       // repetir passes vegades
               x = x + incr;                        // x un poc més a la dreta
               y = baseBoca + alt * Math.sin(alpha);// calcular l'altura
               g.drawLine(x0, y0, (int)x, (int)y);  // linia (x0,y0)-(x,y)
               x0 = (int)x;                         // el nou x0 és l'antic x
               y0 = (int)y;                         // el nou y0 és l'antic y
               alpha = alpha + delta;               // nou angle per seguir
           }
       }
   }

    // NO tenim un interés real en aquest esdeveniment. S'ha de posar per raons
    // de compatibilitat amb la interface
    public void mouseClicked(MouseEvent e) {
    }

    /**
     * Si es pica el botó de la rata s'ha de canviar. Aquest m√®tode √©s
     * l'encarregat de rebre les notificacions de que els botons de la rata
     * s'han picat.
     *
     * Segons sigui el bot√≥ el comportament ser√† un o un altre:
     *    BUTTON1 (bot√≥ esquerra) el tanca l'ull esquerra.
     *    BUTTON3 (bot√≥ dret) el tanca l'ull dret.
     *    BUTTON2 (bot√≥/roda central) canvia la boca, de contenta a trista.
     */
    public void mousePressed(MouseEvent e) {
        if ( e.getButton() == MouseEvent.BUTTON1)
           obert[esquerra] = false;
        else if (e.getButton() == MouseEvent.BUTTON3)
           obert[dret] = false;
        else if (e.getButton() == MouseEvent.BUTTON2)
            boca = trista;
        repaint();
    }

    /**
     * Si s'amollen els botons, aleshores l'estat de la cara torna als
     * valors normals (els dos ulls oberts, la boca contenta).
     */
    public void mouseReleased(MouseEvent e) {
        obert[esquerra] = obert[dret] = true;
        boca = contenta;
        repaint();
    }

    /**
     * NO tenim un interés real en aquest esdeveniment. S'ha de posar per raons
     * de compatibilitat amb la interface.
     * Esdeveniment vinculat a que el cursor entri a la finestra
     */
    public void mouseEntered(MouseEvent e) { }

    /**
     * NO tenim un interés real en aquest esdeveniment. S'ha de posar per raons
     * de compatibilitat amb la interface.
     * Esdeveniment vinculat a que el cursor surti de la finestra
     */
    public void mouseExited(MouseEvent e) { }

    /**
     * NO tenim un interés real en aquest esdeveniment. S'ha de posar per raons
     * de compatibilitat amb la interface.
     * Esdeveniment vinculat a que el cursor es mogui amb algun bot√≥ picat
     */
    public void mouseDragged(MouseEvent e) { }

    /**
     * NO tenim un interés real en aquest esdeveniment. S'ha de posar per raons
     * de compatibilitat amb la interface.
     * Esdeveniment vinculat a que el cursor es mogui sense cap bot√≥ picat
     */
    public void mouseMoved(MouseEvent e) { }

    /**
     * Esdeveniment vinculat a que el la roda central de la rata es mogui.
     */
    public void mouseWheelMoved(MouseWheelEvent e) {
        if (e.getWheelRotation() > 0) factor = 1.0;
        else factor = -1.0;
        boca = nervis;
        repaint();
    }
}

