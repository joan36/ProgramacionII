package _smiley;

import java.awt.event.*;
import javax.swing.*;

/**
 * Implementació d'una classe que extén el comportament d'un JFrame i que
 * servirà com a marc per desenvolupar la nostra aplicació de gràfics.
 *
 * Desenvolupament realitzat a partir de l'exercici de la classe de
 * dia 11/03/2011.
 *
 * Es disposa d'un botó que es pot picar, hi ha una etiqueta que mostra el
 * nombre de vegades que s'ha picat el botó.
 *
 * Es mostra les coordenades del cursor a la finestra.
 *
 * @version 11/03/2011
 *
 * Autor: Pere Palmer
 */
public class Smiley extends JFrame implements ActionListener,
        MouseListener,
        MouseMotionListener {
    // Títol de la finestra

    private static final String titol = "Smiley";
    // Missatge que ha d'apareixer a l'etiqueta de comptar
    private static final String missatge = "El nombre de vegades que"
            + " has picat el botó es ";
    // Missatge que ha d'aparèixer per indicar les coordenades
    private static final String msgCoordenades = "Coordenades del cursor ("
            + "relatives a la finestra a la que està): ";
    // Missatge per quan el cursor surti de la finestra
    private static final String noCursor = "(????,????)";
    // Comptador per determinar el nombre de vegades que es picarà el botó
    private int comptador = 0;
    // Etiqueta per mostrar el missatge del nombre de vegades que s'ha picat
    // el botó
    private JLabel etiqueta, coordenades;

    /**
     * Mètode que compon el missatge que s'ha de mostrar a l'etiqueta
     *
     * @return el missatge composició de l'atribut estàtic final (és a dir
     * constant) i el comptador
     */
    private String compondreMissatge() {
        return missatge + comptador;
    }

    /**
     * Mètode que compon el missatge per mostrar les coordenades. Les
     * coordenades es mostraran amb el format "(xxx, yyy)"
     *
     * @param x la component horitzontal
     * @param y la component vertical
     * @return el missatge compost
     */
    private String compondreMsgCoordenades(int x, int y) {
        return msgCoordenades + "(" + x + ", " + y + ")";
    }

    /**
     * Mètode per mostrar el missatge de coordenades fora de la finestra
     *
     * @return el missatge de les coordenades, però sense coordenades.
     */
    private String foraCoordenades() {
        return msgCoordenades + noCursor;
    }

    // Constructor per defecte
    @SuppressWarnings("LeakingThisInConstructor")
    public Smiley() {
        // Primerament invocar al constructor de la classe base (JFrame) per
        // tal de que la seva inicialització sigui com es desitja, en aquest
        // cas això significa invocar al constructor que rep com argument un
        // String que ve a ser el títol
        super(titol);

        // Crear un panell per col·locar tots els element al seu interior
        JPanel panell = new JPanel();
        // L'organització dels elements es segons un BoxLayout amb organització
        // en vertical
        BoxLayout layout = new BoxLayout(panell, BoxLayout.Y_AXIS);
        panell.setLayout(layout);
        // Etiqueta per mostrar les coordenades on es troba el cursor
        coordenades = new JLabel(foraCoordenades());
        // Afegir l'etiqueta al panell
        panell.add(coordenades);

        // Crear l'etiqueta per comptar les vegades que es pica el botó
        etiqueta = new JLabel(compondreMissatge());

        // Crear el botó No es defineix un atribut, basta amb una variable
        // local per crear-lo
        JButton boto = new JButton("Pica'm!!");
        // Indicar que els esdeveniments de picat s'han de notificar al
        // propi objecte instància de la classe Principal que ara s'està creant.
        boto.addActionListener(this);

        // Afegir l'etiqueta al panell
        panell.add(etiqueta);
        // Afegir el botó al panell (ha de quedar devall de l'etiqueta
        panell.add(boto);

        // Crear una instància de PaperDibuix
        PaperDibuix paper = new PaperDibuix();
        // Afegir-la al panell (devall del botó, segons BoxLayout)
        panell.add(paper);

        // Afegir el panells (amb tot el que té) com element de la finestra
        this.getContentPane().add(panell);

        // Declarar l'interés pels esdeveniments de moviment del cursor a
        // diferents finestres
//        this.addMouseMotionListener(this);
//        this.addMouseListener(this);
        boto.addMouseMotionListener(this);
        boto.addMouseListener(this);
        panell.addMouseMotionListener(this);
        paper.addMouseListener(this);
        paper.addMouseMotionListener(this);

        // El comportament del botó tancar de la finestra és el de fer que
        // el programa finalitzi.
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Compondre el contingut de la finestra de manera que tot es mostri
        // com cal.
        this.pack();
    }

    /**
     * Mètode que serà invocat cada vegada que es piqui el botó de la rata
     * sobre el bot√ó que s'ha afegit a la finestra.
     *
     * @param ae la informació inherent a l'esdeveniment.
     */
    public void actionPerformed(ActionEvent ae) {
        // S'ha d'incrementar el comptador de vegades que s'ha picat el bot√≥
        comptador++;
        // S'ha de mostrar un nou missatge a l'etiqueta.
        etiqueta.setText(compondreMissatge());
    }

    /**
     * Programa principal. S'encarrega bàsicament de crear una instància de la
     * finestra i de fer-la visible a la pantalla.
     *
     * @param args els arguments de la línia de comandes.
     */
    public static void main(String[] args) {
        Smiley finestra = new Smiley();
        finestra.setVisible(true);
    }

    /**
     * Quan el cursor es mou per la finestra amb qualque botó picat es notifica
     * a aquest mètode.
     *
     * @param e la informació inherent a l'esdeveniment
     */
    public void mouseDragged(MouseEvent e) {
        coordenades.setText(compondreMsgCoordenades(e.getX(), e.getY()));
    }

    /**
     * Quan el cursor es mou per la finestra sense picar cap botó es notifica
     * a aquest mètode.
     *
     * @param e la informació inherent a l'esdeveniment
     */
    public void mouseMoved(MouseEvent e) {
        coordenades.setText(compondreMsgCoordenades(e.getX(), e.getY()));
    }

    /**
     * Quan el cursor surti de la finestra s'ha de deixar de mostrar les
     * coordenades.
     *
     * @param e la informació inherent a l'esdeveniment
     */
    public void mouseExited(MouseEvent e) {
        coordenades.setText(foraCoordenades());
    }

    /**
     * No hi ha un interés real per aquest esdeveniment
     */
    public void mouseClicked(MouseEvent e) {
    }

    /**
     * No hi ha un interés real per aquest esdeveniment
     */
    public void mousePressed(MouseEvent e) {
    }

    /**
     * No hi ha un interés real per aquest esdeveniment
//     */
    public void mouseReleased(MouseEvent e) {
    }

    /**
     * No hi ha un interés real per aquest esdeveniment
//     */
    public void mouseEntered(MouseEvent e) {
    }

   

}
