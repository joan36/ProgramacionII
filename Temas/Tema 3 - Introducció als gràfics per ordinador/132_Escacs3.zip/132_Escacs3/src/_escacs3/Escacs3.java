/*
 * Programa que defineix un tauler d'escacs dins un marc i posa dues peces a
 * qualsevol lloc
 *
 */
package _escacs3;

/**
 *
 * @author miquelmascaro
 */
import javax.swing.*;

public class Escacs3 extends JFrame {

    Tauler tauler;

    public Escacs3() {
        super("Escacs");
        tauler = new Tauler();
        tauler.Posa(Pesa.REINAN, 2, 6);
        tauler.Posa(Pesa.CAVALLN, 1, 1);
        this.getContentPane().add(tauler);
        this.setSize(tauler.getPreferredSize());
        this.pack();
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        Escacs3 esc = new Escacs3();
        esc.setVisible(true);
    }
}
