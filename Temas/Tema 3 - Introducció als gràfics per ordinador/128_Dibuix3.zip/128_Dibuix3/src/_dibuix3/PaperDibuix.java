/*
 * La sortida en aquest cas es fa per pantalla però també es fa el render a un
 * fitxer
 */
package _dibuix3;

/**
 *
 * @author miquelmascaro
 */
import java.awt.*;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

class PaperDibuix extends JPanel {

    public static final int MAXX = 500, MAXY = 500;
    private final int COSTAT = MAXX / 5;

    @Override
    public void paintComponent(Graphics g) {
        Graphics2D fitxer = (Graphics2D) g;
        Graphics2D pantalla = (Graphics2D) g;
        BufferedImage bi = new BufferedImage(MAXX, MAXY, BufferedImage.TYPE_INT_RGB);
        fitxer = bi.createGraphics();
        int y = 0;
        for (int i = 1; i <= 5; i++) {
            int x = 0;
            for (int j = 1; j <= 5; j++) {
                Rectangle2D.Float r = new Rectangle2D.Float(x, y, COSTAT, COSTAT);
                float vermell = (float) Math.random();
                float verd = (float) Math.random();
                float blau = (float) Math.random();
                fitxer.setColor(new Color(vermell, verd, blau));
                fitxer.fill(r);
                pantalla.setColor(new Color(vermell, verd, blau));
                pantalla.fill(r);
                Ellipse2D.Float c = new Ellipse2D.Float(x + 5, y + 5, COSTAT - 10, COSTAT - 10);
                fitxer.setColor(Color.YELLOW);
                fitxer.fill(c);
                pantalla.setColor(Color.YELLOW);
                pantalla.fill(c);
                fitxer.setColor(Color.BLACK);
                fitxer.setStroke(new BasicStroke(3.0f));
                fitxer.draw(c);
                pantalla.setColor(Color.BLACK);
                pantalla.setStroke(new BasicStroke(3.0f));
                pantalla.draw(c);
                Arc2D.Float a = new Arc2D.Float(x + 12, y, 75, 75, 225, 90, Arc2D.OPEN);
                fitxer.draw(a);
                pantalla.draw(a);
                Ellipse2D.Float u1 = new Ellipse2D.Float(x + 25, y + 30, 10, 20);
                fitxer.fill(u1);
                pantalla.fill(u1);
                Ellipse2D.Float u2 = new Ellipse2D.Float(x + 65, y + 30, 10, 20);
                fitxer.fill(u2);
                pantalla.fill(u2);
                x += COSTAT;
            }
            y += COSTAT;
        }
        String s = "Smile!";
        pantalla.setFont(new Font("arial", 1, 150));
        pantalla.drawString(s, 25, MAXY + 140);

        File outputfile = new File("smile.png");
        try {
            ImageIO.write(bi, "png", outputfile);
        } catch (Exception e) {
        }



    }
}
