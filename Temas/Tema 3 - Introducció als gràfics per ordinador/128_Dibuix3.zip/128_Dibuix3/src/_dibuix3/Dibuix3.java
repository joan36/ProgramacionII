/*
 * Exemple de dibuix de primitives
 *
 * Al programa principal cream el marc amb el panel que contindrà el gràfic 2D
 */
package _dibuix3;

import javax.swing.JFrame;

public class Dibuix3 extends JFrame {

    private PaperDibuix paper;


    public Dibuix3() {
        this.setSize(PaperDibuix.MAXX, PaperDibuix.MAXY + 200);
        this.setResizable(false);
        this.setTitle("Smileys");
        this.setDefaultCloseOperation(Dibuix3.EXIT_ON_CLOSE);
        paper = new PaperDibuix();
        this.getContentPane().add(paper);
    }
    public static void main(String[] args) {
        new Dibuix3().setVisible(true);
    }
}
