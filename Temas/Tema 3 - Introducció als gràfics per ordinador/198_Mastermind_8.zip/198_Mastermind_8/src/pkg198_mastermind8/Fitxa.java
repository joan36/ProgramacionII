/*
 * Classe Fitxa que defineix les peces per jugar al joc del Mastermind
 *
 * Les fitxes són fitxers d'imatges que representen esferes brillants dels 6
 * colors i nom que les identifica.
 *
 * El constructor llegeix el fitxer amb la imatge i assigna al nom la cadena
 * que passa per paràmetre.
 *
 * El mètode getNom retorna el nom de la peça.
 *
 * El mètode paintComponent pinta la imatge a la posició indicada.
 */
package pkg198_mastermind8;

/**
 *
 * @author miquelmascarooliver
 */
import java.awt.Graphics;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;

public class Fitxa {

    public static final String BLANCA = "fitxes/blanca.png";
    public static final String BLAVA = "fitxes/blava.png";
    public static final String GROGA = "fitxes/groga.png";
    public static final String NEGRA = "fitxes/negra.png";
    public static final String VERDA = "fitxes/verda.png";
    public static final String VERMELLA = "fitxes/vermella.png";
    public static final String BUIDA = "fitxes/buida.png";
    private BufferedImage img;
    private String nom;

    public Fitxa(String s) {
        try {
            img = ImageIO.read(new File(s));
        } catch (IOException e) {
        }
        nom = s;
    }

    public String getNom() {
        return nom;
    }

    void paintComponent(Graphics g, float x, float y) {
        g.drawImage(img, (int) x + 5, (int) y + 5, null);
    }
}
