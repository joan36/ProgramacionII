package pkg198_mastermind8;



import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JPanel;

/**
 * És un panell que conté un paleta de colors del joc mastermind
 * @author miquelmascaro
 */
public class PaletaColors extends JPanel {

    static final int NUMCOLORS = 6;
    static final int COSTAT = Mastermind.COSTAT / 2;
    private static final Color FONS = Color.LIGHT_GRAY;
    private static final Color CUADRE = Color.BLACK;
    static final Color[] col = {Color.BLACK, Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.WHITE};
    private Rectangle2D.Float[] recs;
    public Pin pinActiu;

    /**
     * Crea els rectangles i assigna el pin negre com a actiu
     */
    public PaletaColors() {
        recs = new Rectangle2D.Float[NUMCOLORS];
        int x = this.getX() + 30;
        int y = this.getY();
        for (int i = 0; i < NUMCOLORS; i++) {
            recs[i] = new Rectangle2D.Float(x, y, COSTAT, COSTAT);
            y += COSTAT;
        }
        Rectangle2D.Float r = new Rectangle2D.Float (x - 15, y, Mastermind.COSTAT, Mastermind.COSTAT);
        pinActiu = new Pin(r, ColorFitxa.NEGRA);
    }

    /**
     * Pinta la paleta
     * @param g 
     */
    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        for (int i = 0; i < NUMCOLORS; i++) {
            g2d.setColor(col[i]);
            g2d.fill(recs[i]);
            g2d.setColor(CUADRE);
            g2d.draw(this.recs[i]);
            pinActiu.paintComponent(g);
        }
    }

    /**
     * Detecta si s'ha fet un click dins la paleta de colors 
     * @param x Component x del click del ratolí
     * @param y Component y del click del ratolí
     * @return retorna un enter que és el nombre del color sino és a dins retorna -1
     */
    public int clickADins(int x, int y) {
        boolean trobat = false;
        int i = 0;
        while (!trobat && i < NUMCOLORS) {
            trobat = this.recs[i].contains(x, y);
            i++;
        }
        if (trobat) {
            return i - 1;
        } else {
            return -1;
        }
    }

    public void posaColor(ColorFitxa c) {       
        pinActiu.posaColor(c);
        repaint();
    }

}
