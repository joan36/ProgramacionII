/*
 * Classe DialegFinal del joc mastermind
 * 
 * ATRIBUTS
 * Una etiqueta amb el missatge i un boto per tornar al joc
 * 
 * CONSTRUCTOR
 * Crea l'etiqueta amb l'string que passa per paràmetre,
 * el boto simplement amaga el diàleg
 */
package pkg198_mastermind8;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;

/**
 *
 * @author miquelmascaro
 */
class DialegFinal extends JDialog {

    private JLabel jlbGuanyador;
    private JButton jbtOk;

    public DialegFinal(String s) {
        jlbGuanyador = new JLabel(s);
        jlbGuanyador.setFont(new Font("arial", 1, 30));
        jlbGuanyador.setAlignmentY(CENTER_ALIGNMENT);
        jbtOk = new JButton("Acceptar");
        this.getContentPane().setLayout(new BorderLayout(20, 10));
//        this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));

        this.add(jlbGuanyador, BorderLayout.NORTH);
        this.add(jbtOk, BorderLayout.CENTER);
        this.setSize(200, 100);
        this.setLocationRelativeTo(this);
        this.setResizable(false);
        this.setVisible(true);
        jbtOk.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
    }
}
