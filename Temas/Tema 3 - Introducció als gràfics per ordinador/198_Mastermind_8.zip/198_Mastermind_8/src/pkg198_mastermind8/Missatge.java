/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg198_mastermind8;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JPanel;

/**
 *
 * @author miquelmascaro
 */
class Missatge extends JPanel{
    
    private static final Color FONS = Color.LIGHT_GRAY;
    private static final Color CUADRE = Color.BLACK;
    private Rectangle2D.Float rec;
    private String missatge;
    
    public Missatge (String s) {
        int x = this.getX();
        int y = this.getY();
        rec = new Rectangle2D.Float(x, y, 119, 119);
        missatge = s;
    }
    
    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setFont(new Font("arial",1,73));
        g2d.clearRect((int) this.rec.x, (int) this.rec.y + 1, (int) this.rec.width, (int) this.rec.height);
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.drawString(missatge, rec.x , rec.height - 30);
        g2d.setFont(new Font("arial",1,25));
        g2d.drawString("  ASSAIG", rec.x , rec.height - 95);
//        g2d.setColor(CUADRE);
//        g2d.draw(this.rec);
    }

    void setMissatge(String s) {
        this.missatge = s;
        Graphics2D g2d = null;
        repaint();
    }
}
