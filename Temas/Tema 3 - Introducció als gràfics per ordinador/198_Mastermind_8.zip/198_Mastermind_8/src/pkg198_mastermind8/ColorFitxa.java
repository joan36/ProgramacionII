package pkg198_mastermind8;

/**
 * Classe enumerat amb els colors del joc del Mastermind
 * @author miquelmascarooliver
 */
public enum ColorFitxa {

    NEGRA, VERMELLA, VERDA, BLAVA, GROGA, BLANCA;

    /**
     * Donat un enter retorna un enumerat amb els valors: 
     * NEGRA, VERMELLA, VERDA, BLAVA, GROGA, BLANCA
     * @param i enter que es converteix a color
     * @return color de retorn
     */
    public static ColorFitxa intToColor(int i) {
        if (i == 0) {
            return NEGRA;
        } else if (i == 1) {
            return VERMELLA;
        } else if (i == 2) {
            return VERDA;
        } else if (i == 3) {
            return BLAVA;
        } else if (i == 4) {
            return GROGA;
        } else {
            return BLANCA;
        }
    }
}
