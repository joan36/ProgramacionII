/*
 * Classe FitxaPetita que defineix les peces per jugar al joc del Mastermind
 *
 * Les fitxes són fitxers d'imatges que representen esferes brillants blanques
 * i negresi nom que les identifica.
 *
 * El constructor llegeix el fitxer amb la imatge i assigna al nom la cadena
 * que passa per paràmetre.
 *
 * El mètode getNom retorna el nom de la peça.
 *
 * El mètode paintComponent pinta la imatge a la posició indicada.
 */
package pkg198_mastermind8;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 *
 * @author miquelmascaro
 */
class FitxaPetita {

    public static final String BLANCA = "fitxes/blancaPetita.png";
    public static final String NEGRA = "fitxes/negraPetita.png";
    public static final String BUIDA = "fitxes/buidaPetita.png";
    private BufferedImage img;
    private String nom;

    public FitxaPetita(String s) {
        try {
            img = ImageIO.read(new File(s));
        } catch (IOException e) {
        }
        nom = s;
    }

    public String getNom() {
        return nom;
    }

    void paintComponent(Graphics g, float x, float y) {
        g.drawImage(img, (int) x + 3, (int) y + 3, null);
    }
}
