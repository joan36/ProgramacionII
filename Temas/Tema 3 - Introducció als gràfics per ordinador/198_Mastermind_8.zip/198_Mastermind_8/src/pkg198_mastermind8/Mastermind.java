/*
 * Joc del Mastermind
 */
package pkg198_mastermind8;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;
import javax.swing.*;

/**
 *
 * @author miquelmascaro
 */
public class Mastermind extends JFrame implements MouseListener {

    /**
     * @param args the command line arguments
     */
    // Constants utilitzades pel joc i per distribuir els elements gràfics a la
    // pantalla
    static final int MAXINTENTS = 10;
    static final int COSTAT = 60;
    static final int CODISX = 150;
    static final int SECRETY = 50;
    static final int INTENTSY = 700;
    // Atributs dels joc
    // secret: és el codi secret que ha d'endevinar el jugador
    // intents: llista de Codis de MAXINTENTS que té el jugador per anar assatjant el
    // codi secret
    // prova: és el num d'assaig del jugador i índex dels intents comença a 0
    // fins al 9
    // m: és el missatge que indica l'intennt en curs
    // paleta: serveix per triar el color a posar dins l'intent
    // valida: el botó que perment avaluar l'intent
    // resposta: és el resultat d'avaluar cada intent
    // dialeg: és la finestra de diàleg que surt quan es guanya (s'encerta el
    // secret) o perd el joc (es fan el MAXINTENTS sense encertar el secret)
    // jmbarMastermind: barra del menú del joc
    // jmnuJoc: Menú del joc
    // jmItemSortir: Opció del menú que permet sortir de l'aplicació
    // jmItemReiniciar: Opció del menú que permet començar un nou joc
    // jmItemHelp: Opció del joc que revel·la el codi secret
    private Codi secret;
    private Codi[] intents;
    private int prova;
    private Missatge m;
    private PaletaColors paleta;
    private JButton valida;
    private Resposta[] resposta;
    private DialegFinal dialeg;
    private JMenuBar jmbarMastermind;
    private JMenu jmnuJoc;
    private JMenuItem jmItemSortir;
    private JMenuItem jmItemReiniciar;
    private JMenuItem jmItemHelp;

    // Constructor del joc, posa el títol a la finestra, inicialitza les
    // les components, col·loca la finestra del joc al centre de la pantalla i
    // habilita poder tancar la finestra
    public Mastermind() {
        super("Mastermind");
        initComponents();
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    // Programa principal, crida al constructor del joc i fa visible la finestra
    public static void main(String[] args) {
        Mastermind joc = new Mastermind();
        joc.setVisible(true);
    }

    // Inicialització de totes les components
    private void initComponents() {
        this.setLayout(null); // Les components es distribueixen indicant els seus límits
        Random rnd = new Random();
        secret = new Codi(rnd); // El secret es crea amb un aleatori
        secret.setBounds(CODISX, SECRETY, (COSTAT * 4) + 1, COSTAT + 1);
        secret.setVisible(false); // És invisible
        this.getContentPane().add(secret);

        intents = new Codi[MAXINTENTS];
        int y = INTENTSY;
        for (int i = 0; i < MAXINTENTS; i++) {
            intents[i] = new Codi();
            intents[i].setBounds(CODISX, y, (COSTAT * 4) + 1, COSTAT + 1);
            intents[i].addMouseListener(this); // Es pot fer click sobre cada un
            this.getContentPane().add(intents[i]);
            y -= COSTAT;
        }
        prova = 0;

        String s = componMissatge(prova);
        m = new Missatge(s);
        m.setBounds(20, SECRETY - 30, COSTAT * 2, COSTAT * 2);
        this.getContentPane().add(m);

        paleta = new PaletaColors();
        paleta.setBounds(CODISX + (COSTAT * 4), INTENTSY - (COSTAT * 6), COSTAT * 2, (COSTAT * 6) + 1);
        paleta.addMouseListener(this); // Per seleccionar el color
        this.getContentPane().add(paleta);

        resposta = new Resposta[MAXINTENTS];
        y = INTENTSY;
        for (int i = 0; i < MAXINTENTS; i++) {
            resposta[i] = new Resposta();
            resposta[i].setBounds(CODISX - COSTAT - 30, y, COSTAT + 1, COSTAT + 1);
            this.getContentPane().add(resposta[i]);
            y -= COSTAT;
        }

        valida = new JButton();
        valida.setToolTipText("Avalua l'assaig");
        valida.setText("Valida");
        valida.setBounds(CODISX + COSTAT, INTENTSY + COSTAT + 10, COSTAT * 2, COSTAT - 20);
        valida.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                if (prova < MAXINTENTS) { // En haver acabat no es pot seguir avaluant
                    if (!intents[prova].faltenFitxes()) { // no s'ha d'avaluar si queden fitxer per posar a l'intent
                        resposta[prova].avalua(intents[prova], secret);
                        if (resposta[prova].totesBe()) {
                            dialeg = new DialegFinal(" Has guanyat!");
                            secret.setVisible(true);
                        } else {
                            prova++;
                            if (prova == MAXINTENTS) {
                                dialeg = new DialegFinal(" Has perdut! ");
                                secret.setVisible(true);
                            } else { // Continua amb un nou intent
                                String s = componMissatge(prova);
                                m.setMissatge(s);
                            }

                        }
                    }
                }

            }
        });
        this.getContentPane().add(valida);

        jmbarMastermind = new JMenuBar();
        jmnuJoc = new JMenu("Joc");
        jmItemSortir = new JMenuItem("Sortir");
        jmItemSortir.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_Q, ActionEvent.META_MASK));
        jmItemSortir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                System.exit(0);
            }
        });
        jmItemReiniciar = new JMenuItem("Reiniciar");
        jmItemReiniciar.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_N, ActionEvent.META_MASK));
        jmItemReiniciar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                for (int i = 0; i < MAXINTENTS; i++) {
                    intents[i].reinicia();
                    resposta[i].reinicia();
                }
                prova = 0;
                String s = componMissatge(prova);
                m.setMissatge(s);
                Random rnd = new Random();
                secret.reinicia(rnd);
                secret.setVisible(false);
                repaint();
            }
        });
        jmItemHelp = new JMenuItem("Solució");
        jmItemHelp.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_S, ActionEvent.META_MASK));
        jmItemHelp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                secret.setVisible(true);
                repaint();
            }
        });
        jmnuJoc.add(jmItemHelp);
        jmnuJoc.add(jmItemReiniciar);
        jmnuJoc.add(jmItemSortir);
        jmbarMastermind.add(jmnuJoc);

        this.setJMenuBar(jmbarMastermind);
        this.pack();
        this.setResizable(false);
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(COSTAT * 8, INTENTSY + 180);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    // Es detecten clicks sobre la paleta i sobre l'intent actiu
    @Override
    public void mouseReleased(MouseEvent e) {
        int x = 0, y = 0;
        Component comp = null;
        if (e.getButton() == MouseEvent.BUTTON1) {
            x = e.getX();
            y = e.getY();
            comp = e.getComponent();
        }
        if (comp == paleta && paleta.clickADins(x, y) != -1) {
            ColorFitxa c = ColorFitxa.intToColor(paleta.clickADins(x, y));
            paleta.posaColor(c);
        }
        if (prova < MAXINTENTS) { // si s'ha superat el nombre d'intents no es miren els clicks
            if (comp == intents[prova] && !resposta[prova].totesBe()) { // si encara no s'ha guanyat
                intents[prova].posaPin(paleta.pinActiu, x, y);
            }
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    private String componMissatge(int prova) {
        int i = prova + 1;
        if (i < 10) {
            return " #" + i;
        } else {
            return "#" + i;
        }
    }
}
