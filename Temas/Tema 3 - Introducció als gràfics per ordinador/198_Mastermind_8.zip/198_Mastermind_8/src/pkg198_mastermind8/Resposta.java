/*
 * Classe Resposta del joc del mastermind
 * 
 * ATRIBUTS
 * Una resposta és un array de 4 PinPetit
 * 
 * CONSTRUCTOR
 * Es creen els 4 PinPetit
 * 
 * MÈTODES
 * paintComponent: pinta els 4 PinPetit
 * avalua: A partir de dos Codis col·loca PinPetit negres per tots els Pin
 * coincidents i PinPetit blancs per a tots els colors coincidents fora
 * dels anteriors
 * totesBe: Retorna vertader si els 4 són negres
 * reinicia: Buida tot l'array
 */
package pkg198_mastermind8;

import java.awt.Graphics;
import java.awt.geom.Rectangle2D;
import javax.swing.JPanel;

/**
 *
 * @author miquelmascaro
 */
class Resposta extends JPanel {

    static final int COSTAT = 60 / 2;
    static final int DIMENSIO = 4;
    private PinPetit s[];

    public Resposta() {
        s = new PinPetit[DIMENSIO];
        int x = this.getX();
        int y = this.getY();
        for (int i = 0; i < DIMENSIO / 2; i++) {
            Rectangle2D.Float r = new Rectangle2D.Float(x, y, COSTAT, COSTAT);
            s[i] = new PinPetit(r);
            x += COSTAT;
        }
        x = this.getX();
        for (int i = 2; i < DIMENSIO; i++) {
            Rectangle2D.Float r = new Rectangle2D.Float(x, y + COSTAT, COSTAT, COSTAT);
            s[i] = new PinPetit(r);
            x += COSTAT;
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        for (int i = 0; i < DIMENSIO; i++) {
            s[i].paintComponent(g);
        }
    }

    void avalua(Codi intent, Codi secret) {
        int totOk = secret.avaluaOk(intent);
        int colorOk = secret.avaluaColor(intent);
        colorOk = colorOk - totOk;
        int i;
        for (i = 0; i < totOk; i++) {
            s[i].posaColor(ColorFitxa.NEGRA);
        }
        for (int j = 0; j < colorOk; j++) {
            s[i].posaColor(ColorFitxa.BLANCA);
            i++;
        }
        repaint();
    }

    public boolean totesBe() {
        int numBe = 0;
        for (int i = 0; i < DIMENSIO; i++) {
            if (!s[i].isBuida() && s[i].getColor() == ColorFitxa.NEGRA) {
                numBe++;
            }
        }
        return numBe == DIMENSIO;
    }

    void reinicia() {
        for (int i = 0; i < DIMENSIO; i++) {
            s[i].setBuida();
        }
    }
}
