/*
 * Classe Pin del joc del Mastermind
 * 
 * ATRIBUTS
 * Un rectangle, una Fitza i un booleà que indica si no hi ha fitxa
 * 
 * COSNTRUCTORS
 * Amb un rectangle i un color: Assigna el rectangle i posa la fitxa del color
 * Amb un rectangle: Assigna el rectangle i deixa la fitxa sense posar
 * 
 * MÈTODES
 * paintComponent: Pinta el Pin
 * posaColor: Posa la fitxa del color indicat
 * getRect: torna el rectangle
 * getColor: torna el coor de la fitxa
 * isBuida: torna vertader si esta buida
 * setBuida: actualitza el booleà
 */
package pkg198_mastermind8;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

/**
 * Classe Pin del joc del Mastermind
 * @author miquelmascaro
 */
public class Pin {

    private static final Color FONS = Color.LIGHT_GRAY;
    private static final Color CUADRE = Color.BLACK;
    private Rectangle2D.Float rec;
    private Fitxa fit;
    private boolean buida;

    Pin(Rectangle2D.Float r, ColorFitxa c) {
        this.rec = r;
        buida = false;
        switch (c) {
            case NEGRA:
                this.fit = new Fitxa(Fitxa.NEGRA);
                break;
            case VERMELLA:
                this.fit = new Fitxa(Fitxa.VERMELLA);
                break;
            case VERDA:
                this.fit = new Fitxa(Fitxa.VERDA);
                break;
            case BLAVA:
                this.fit = new Fitxa(Fitxa.BLAVA);
                break;
            case GROGA:
                this.fit = new Fitxa(Fitxa.GROGA);
                break;
            case BLANCA:
                this.fit = new Fitxa(Fitxa.BLANCA);
                break;
        }
    }

    Pin(Rectangle2D.Float r) {
        this.rec = r;
        buida = true;
        this.fit = new Fitxa(Fitxa.BUIDA);
    }

    void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
//        g2d.setColor(FONS);
//        g2d.fill(this.rec);
        g2d.clearRect((int) this.rec.x, (int) this.rec.y + 1, (int) this.rec.width, (int) this.rec.height);
//        g2d.setColor(CUADRE);
//        g2d.draw(this.rec);
        this.fit.paintComponent(g, this.rec.x, this.rec.y);
    }

    void posaColor(ColorFitxa c) {
        buida = false;
        switch (c) {
            case NEGRA:
                this.fit = new Fitxa(Fitxa.NEGRA);
                break;
            case VERMELLA:
                this.fit = new Fitxa(Fitxa.VERMELLA);
                break;
            case VERDA:
                this.fit = new Fitxa(Fitxa.VERDA);
                break;
            case BLAVA:
                this.fit = new Fitxa(Fitxa.BLAVA);
                break;
            case GROGA:
                this.fit = new Fitxa(Fitxa.GROGA);
                break;
            case BLANCA:
                this.fit = new Fitxa(Fitxa.BLANCA);
                break;
        }

    }

    public Rectangle2D.Float getRect() {
        return this.rec;
    }

    public ColorFitxa getColor() {
            if (this.fit.getNom().equals(Fitxa.BLANCA)) {
                return ColorFitxa.BLANCA;
            } else if (this.fit.getNom().equals(Fitxa.BLAVA)) {
                return ColorFitxa.BLAVA;
            } else if (this.fit.getNom().equals(Fitxa.GROGA)) {
                return ColorFitxa.GROGA;
            } else if (this.fit.getNom().equals(Fitxa.NEGRA)) {
                return ColorFitxa.NEGRA;
            } else if (this.fit.getNom().equals(Fitxa.VERDA)) {
                return ColorFitxa.VERDA;
            } else {
                return ColorFitxa.VERMELLA;
            }
    }

    boolean isBuida() {
        return buida;
    }

    void setBuida() {
        this.buida = true;
        this.fit = new Fitxa(Fitxa.BUIDA);
    }
}
