
/*
 * Classe PinPetit del joc del Mastermind
 * 
 * ATRIBUTS
 * Un rectangle, una Fitza i un booleà que indica si no hi ha fitxa
 * 
 * COSNTRUCTORS
 * Amb un rectangle i un color: Assigna el rectangle i posa la fitxa del color
 * Amb un rectangle: Assigna el rectangle i deixa la fitxa sense posar
 * 
 * MÈTODES
 * paintComponent: Pinta el Pinpetit
 * posaColor: Posa la fitxa del color indicat
 * getColor: torna el coor de la fitxa
 * isBuida: torna vertader si esta buida
 * setBuida: actualitza el booleà
 */
package pkg198_mastermind8;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

/**
 *
 * @author miquelmascaro
 */
class PinPetit {

    private static final Color FONS = Color.LIGHT_GRAY;
    private static final Color CUADRE = Color.BLACK;
    private Rectangle2D.Float rec;
    private FitxaPetita fit;
    private boolean buida;

    public PinPetit(Rectangle2D.Float r) {
        this.rec = r;
        this.buida = true;
        this.fit = new FitxaPetita(FitxaPetita.BUIDA);
    }

    void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
//        g2d.setColor(FONS);
//        g2d.fill(this.rec);
//        g2d.setColor(CUADRE);
//        g2d.draw(this.rec);
        this.fit.paintComponent(g, this.rec.x, this.rec.y);
    }

    void posaColor(ColorFitxa c) {
        this.buida = false;
        switch (c) {
            case NEGRA:
                this.fit = new FitxaPetita(FitxaPetita.NEGRA);
                break;
            case BLANCA:
                this.fit = new FitxaPetita(FitxaPetita.BLANCA);
                break;
        }

    }

    public ColorFitxa getColor() {
        if (this.fit.getNom().equals(FitxaPetita.BLANCA)) {
            return ColorFitxa.BLANCA;
        } else {
            return ColorFitxa.NEGRA;
        }
    }

    public boolean isBuida() {
        return this.buida;
    }

    void setBuida() {
        this.buida = true;
        this.fit = new FitxaPetita(FitxaPetita.BUIDA);
    }
}
