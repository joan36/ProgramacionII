/*
 * Classe Codi del joc Mastermind
 * 
 * ATRIBUTS
 * Un codi és un array de dimensió DIMENSIO de Pin
 * 
 * CONSTRUCTORS
 * Amb random: Construeix un objecte Codi amb colors aleatoris
 * Sense paràmetres: Construeix un objecte Codi sense Pin (buit)
 * 
 * MÈTODES
 * paintComponent: Pinta el codi
 * posaPin: col·loca un Pin amb el color actiu a la posició on s'ha fet el click
 * avaluaOK: comprova si totes els Pin del codi es corresponen amb els Pins del 
 * codi que passa per paràmetre
 * avaluaColor: comprova la coincidència de colors del codi amb els Pins del 
 * Codi passat per paràmetre, no tenen per que coincidir en posició
 * faltenFitxes: Mira si hi ha alguna posició del Codi buida
 * reinicia (sense paràmetres): Buida totes les posicions del Codi
 * reinicia (amb random): Omple totes les posicions del codi amb pins de colors
 * aleatoris
 */
package pkg198_mastermind8;

import java.awt.Graphics;
import java.awt.geom.Rectangle2D;
import java.util.Random;
import javax.swing.JPanel;

/**
 *
 * @author miquelmascaro
 */
public class Codi extends JPanel {

    static final int COSTAT = 60;
    static final int DIMENSIO = 4;
    private Pin s[];

    public Codi(Random rnd) {
        s = new Pin[DIMENSIO];
        int x = this.getX();
        int y = this.getY();
        for (int i = 0; i < DIMENSIO; i++) {
            Rectangle2D.Float r = new Rectangle2D.Float(x, y, COSTAT, COSTAT);
            ColorFitxa c = ColorFitxa.values()[rnd.nextInt(ColorFitxa.values().length)];
            s[i] = new Pin(r, c);
            x += COSTAT;
        }
    }

    public Codi() {
        s = new Pin[DIMENSIO];
        int x = this.getX();
        int y = this.getY();
        for (int i = 0; i < DIMENSIO; i++) {
            Rectangle2D.Float r = new Rectangle2D.Float(x, y, COSTAT, COSTAT);
            s[i] = new Pin(r);
            x += COSTAT;
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        for (int i = 0; i < DIMENSIO; i++) {
            s[i].paintComponent(g);
        }
    }

    void posaPin(Pin pinActiu, int x, int y) {
        boolean trobat = false;
        int i = 0;
        while (!trobat && i < DIMENSIO) { // Cerca la posició del codi amb les coordenades del click
            trobat = s[i].getRect().contains(x, y);
            i++;
        }
        i--;
        ColorFitxa c = pinActiu.getColor();
        s[i].posaColor(c);
        repaint();
    }

    public int avaluaOk(Codi intent) {
        int ok = 0;
        for (int i = 0; i < DIMENSIO; i++) {
            if (this.s[i].getColor() == intent.s[i].getColor()) {
                ok++;
            }
        }
        return ok;
    }

    public int avaluaColor(Codi intent) {
        int colorOk = 0;
        boolean pillat[] = new boolean[DIMENSIO]; // taula de booleans que marca les posicions on s'ha trobat la coincidència d'un color
        for (int i = 0; i < DIMENSIO; i++) {
            pillat[i] = false;
        }
        for (int i = 0; i < DIMENSIO; i++) { //c cerca cada color disn el codi passat per paràmetre
            boolean trobat = false;
            int j = 0;
            while (!trobat && j < DIMENSIO) {
                trobat = this.s[i].getColor() == intent.s[j].getColor() && !pillat[j]; // que no s'hagi mirat abans
                j++;
            }
            if (trobat) {
                pillat[j - 1] = true;
                colorOk++;
            }
        }
        return colorOk;
    }

    public boolean faltenFitxes() {
        boolean trobat = false;
        int i = 0;
        while (!trobat && i < DIMENSIO) {
            trobat = s[i].isBuida();
            i++;
        }
        return trobat;
    }

    void reinicia() {
        for (int i = 0; i < DIMENSIO; i++) {
            s[i].setBuida();
        }
    }

    void reinicia(Random rnd) {
        for (int i = 0; i < DIMENSIO; i++) {
            ColorFitxa c = ColorFitxa.values()[rnd.nextInt(ColorFitxa.values().length)];
            s[i].posaColor(c);            
        }
    }
}
