/*
 * Classe punt 3D definit com a tres components a l'espai x, y, z.
 * El cosntructor crea el punt a l'orige o a les coordenades passades per
 * paràmetre.
 *
 * El mètode distància calcula la distància euclídia a l'espai.
 */
package DefPunts3D;

/**
 *
 * @author miquelmascarooliver
 */
import java.lang.Math;

public class punt3D {

    private double x, y, z;

    public punt3D() {
        x = 0;
        y = 0;
        z = 0;
    }

    public punt3D(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public double distancia(punt3D p) {
        return Math.sqrt(Math.pow(x - p.x, 2) + Math.pow(y - p.y, 2)
                + Math.pow(z - p.z, 2));
    }

    @Override
    public String toString() {
        return("(" + x + ", " + y + ", " + z + ")");
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getZ() {
        return z;
    }

    boolean menor(punt3D p) {
        if (this.x < p.x) {
            return true;
        } else if (this.x == p.x && this.y < p.y) {
            return true;
        } else if (this.x == p.x && this.y == p.y && this.z < p.z) {
            return true;
        } else {
            return false;
        }
    }

}
