/*
 * Classe FitxerPunts3D permet definir fitxers d'accés aleatòri que
 * emmagatzemen punts 3D definits a la classe punts3D
 *
 * Te en compte que els elements del fitxer són tres doubles (3 * 8) bytes
 *
 * El constructor crea el fitxer i el tanca
 *
 * El mètode genera drea un fitxer aleatòri de MAX elements
 *
 * Escriu és un recorregut del fitxer llegint i escrivint per la pantalla
 *
 * Ordena aplica el mètode d'ordenació per selecció directe per a ordenar els
 * elements
 */
package DefPunts3D;

/**
 *
 * @author miquelmascarooliver
 */
import java.io.File;
import java.io.RandomAccessFile;
import java.util.Random;

public class FitxerPunts3D {

    private static final int TAMANYREG = 3 * 8; //3 doubles per 8 bytes cada un
    private RandomAccessFile f;
    private String nom;

    public FitxerPunts3D(String nom) throws Exception {
        this.nom = nom;
        File arxiu = new File(nom);
        f = new RandomAccessFile(arxiu, "rw");
        f.close();
    }

    public void genera() {
        final int MAX = 500;
        Random rnd = new Random();
        try {
            File arxiu = new File(nom);
            f = new RandomAccessFile(arxiu, "rw");
            for (int i = 0; i < rnd.nextInt(MAX); i++) {
                double x = rnd.nextInt(MAX);
                double y = rnd.nextInt(MAX);
                double z = rnd.nextInt(MAX);
                f.writeDouble(x);
                f.writeDouble(y);
                f.writeDouble(z);
            }
            f.close();
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    public void escriu() {
        try {
            double x, y, z;
            File arxiu = new File(nom);
            f = new RandomAccessFile(arxiu, "r");
            long numreg = f.length() / TAMANYREG;
            for (int r = 0; r < numreg; r++) {
                x = f.readDouble();
                y = f.readDouble();
                z = f.readDouble();
                punt3D p = new punt3D(x, y, z);
                System.out.println("Punt " + r + ": " + p);
            }
            f.close();
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    public void ordena() {
        try {
            File arxiu = new File(nom);
            f = new RandomAccessFile(arxiu, "rw");
            long numreg = f.length() / TAMANYREG;
            double x, y, z;
            int i, j, jmin;
            punt3D min, p;
            for (i = 0; i < numreg - 1; i++) {
                f.seek(i * TAMANYREG);
                x = f.readDouble();
                y = f.readDouble();
                z = f.readDouble();
                min = new punt3D(x, y, z);
                jmin = i;
                for (j = i + 1; j < numreg; j++) {
                    f.seek(j * TAMANYREG);
                    x = f.readDouble();
                    y = f.readDouble();
                    z = f.readDouble();
                    p = new punt3D(x, y, z);
                    if (p.menor(min)) {
                        min = p;
                        jmin = j;
                    }
                }
                f.seek(i * TAMANYREG);
                x = f.readDouble();
                y = f.readDouble();
                z = f.readDouble();
                p = new punt3D(x, y, z);
                f.seek(i * TAMANYREG);
                f.writeDouble(min.getX());
                f.writeDouble(min.getY());
                f.writeDouble(min.getZ());
                f.seek(jmin * TAMANYREG);
                f.writeDouble(p.getX());
                f.writeDouble(p.getY());
                f.writeDouble(p.getZ());
            }
            f.close();
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }
}
