/*
 * Programa que genera un fitxer amb un nombre aleatori de punts 3D i
 * els ordena
 */

package _operacionspunts4;

/**
 *
 * @author miquelmascarooliver
 */

import DefPunts3D.*;

public class OperacionsPunts4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            FitxerPunts3D f = new FitxerPunts3D("punts.dat");
            f.genera();
            f.escriu();
            f.ordena();
            System.out.println("Ordenat");
            f.escriu();
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

}
