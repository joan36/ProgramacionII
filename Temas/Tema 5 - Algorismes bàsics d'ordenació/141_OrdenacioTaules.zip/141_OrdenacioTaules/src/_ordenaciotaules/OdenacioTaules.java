/*
 * El mètode insercioDirecta ordena una taula de N elements emprant el mètode
 * que insereix l'element i-èssim a la seva posició de la part oredena de la
 * taula. Per ordenar la taula seran necessàries N-1 passades ja que
 * inicialment suposarem que la part ordenada està formada pel primer element.
 */
package _ordenaciotaules;

/**
 *
 * @author miquelmascarooliver
 */
import java.util.Random;

public class OdenacioTaules {

    /**
     * @param args the command line arguments
     */
    public static void emplenarAleatoriament(Dades[] t, int vsup) {
        Random rnd = new Random();
        for (int i = 0; i < t.length; i++) {
            t[i] = new Dades(rnd.nextInt(vsup));
        }
    }

    public static String escriureTaula(Dades[] t) {
        String resultat = "";
        for (int i = 0; i < t.length; i++) {
            resultat += t[i].clau + " ";
        }
        return resultat;
    }

    private static void insercioDirecta(Dades[] t) {
        final int N = t.length;
        int j;
        Dades x;

        for (int i = 1; i < N; i++) {
            x = t[i];
            j = i - 1;
            while ((j >= 0) && (x.clau < t[j].clau)) {
                t[j + 1] = t[j]; // Moure l'element cap a la dreta
                j--;
            }
            //j és el primer o és menor que l'i-èssim
            t[j + 1] = x;	 // inserir el valor de l'element  i-èssim
            System.out.println("Passada " + i + ": " + escriureTaula(t));
        }
    }

    public static void main(String[] args) {
        final int N = 20;
        Dades t[] = new Dades[N];
        emplenarAleatoriament(t, 100);
        System.out.println("Exemple d'ordenació de taules amb el mètode"
                + " d'Inserció directa\n");
        System.out.println("Valors a ordenar: " + escriureTaula(t) + "\n");
        insercioDirecta(t);
        System.out.println("\nTaula ordenada: " + escriureTaula(t));
    }
}
