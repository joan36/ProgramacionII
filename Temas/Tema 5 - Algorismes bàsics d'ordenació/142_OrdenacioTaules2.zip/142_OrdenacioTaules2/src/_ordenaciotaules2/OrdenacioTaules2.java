/*
 * El mètode seleccioDirecta ordena una taula de N elements amb el mètode de
 * Selecció directa que es basa en fer N-1 passades i a cada passada cerca
 * l'element més petit i el posa a la posició i-èssima, basten N-1 passades
 * per que el darrer element ja estarà ordenat.
 */
package _ordenaciotaules2;

/**
 *
 * @author miquelmascarooliver
 */
import java.util.Random;

public class OrdenacioTaules2 {

    /**
     * @param args the command line arguments
     */
    public static void emplenarAleatoriament(Dades[] t, int vsup) {
        Random rnd = new Random();
        for (int i = 0; i < t.length; i++) {
            t[i] = new Dades(rnd.nextInt(vsup));
        }
    }

    public static String escriureTaula(Dades[] t) {
        String resultat = "";
        for (int i = 0; i < t.length; i++) {
            resultat += t[i].clau + " ";
        }
        return resultat;
    }

    private static void seleccioDirecta(Dades[] t) {
        final int N = t.length;
        int jmin;
        Dades min;

        for (int i = 0; i < N - 1; i++) {
            min = t[i];
            jmin = i;
            for (int j = i + 1; j < N; j++) {
                if (t[j].clau < min.clau) {
                    min = t[j];
                    jmin = j;
                }
            }
            t[jmin] = t[i];
            t[i] = min;
            System.out.println("Passada " + i + ": " + escriureTaula(t));
        }
    }

    public static void main(String[] args) {
        final int N = 10;
        Dades t[] = new Dades[N];
        emplenarAleatoriament(t, 100);
        System.out.println("Exemple d'ordenació de taules amb el mètode"
                + " de Selecció directa\n");
        System.out.println("Valors a ordenar: " + escriureTaula(t) + "\n");
        seleccioDirecta(t);
        System.out.println("\nTaula ordenada: " + escriureTaula(t));
    }
}
