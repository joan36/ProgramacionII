

package _ordenaciotaules5;

/**
 *
 * @author miquelmascarooliver
 */
public class Dades {

    public int clau;

    public Dades(int valor) {
        this.clau = valor;
    }

}
