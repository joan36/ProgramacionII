/*
 * Ordenació de taules amb el mètode de la espolçada.
 * Aquest mètode du a terme dues bombolles millorades (una en cada sentit) per a
 * cada passada. Usa dos índex esq i dre que quan es trobin acabarà l'algorisme.
 * S'actualitzen amb una variable lj similar a la que s'usa a l'algorisme de
 * la bombolla millorada i que detecta les posicions on hi hagut l'intercanvi.
 * 
 */
package _ordenaciotaules5;

/**
 *
 * @author miquelmascarooliver
 */
import java.util.Random;

public class OrdenacioTaules5 {

    public static void emplenarAleatoriament(Dades[] t, int vsup) {
        Random rnd = new Random();
        for (int i = 0; i < t.length; i++) {
            t[i] = new Dades(rnd.nextInt(vsup));
        }
    }

    public static String escriureTaula(Dades[] t) {
        String resultat = "";
        for (int i = 0; i < t.length; i++) {
            resultat += t[i].clau + " ";
        }
        return resultat;
    }

    private static void espolsada(Dades[] t) {
        final int N = t.length;
        Dades x;
        int esq = 0, dre = N - 1;
        while (esq < dre) {
            int lj = dre;
            for (int j = dre - 1; j >= esq; j--) {
                if (t[j + 1].clau < t[j].clau) {
                    x = t[j + 1];
                    t[j + 1] = t[j];
                    t[j] = x;
                    lj = j;
                }
            }
            esq = lj + 1;
            for (int j = esq; j <= dre - 1; j++) {
                if (t[j + 1].clau < t[j].clau) {
                    x = t[j + 1];
                    t[j + 1] = t[j];
                    t[j] = x;
                    lj = j + 1;
                }
            }
            dre = lj - 1;
            System.out.println("dre = " + dre + " esq = " + esq +
                    ": " + escriureTaula(t));
        }
    }

    public static void main(String[] args) {
        final int N = 10;
        Dades t[] = new Dades[N];
        emplenarAleatoriament(t, 100);
        System.out.println("Exemple d'ordenació de taules amb el mètode"
                + " de la espolçada\n");
        System.out.println("Valors a ordenar: " + escriureTaula(t) + "\n");
        espolsada(t);
        System.out.println("\nTaula ordenada: " + escriureTaula(t));
    }
}
